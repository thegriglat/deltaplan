## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.50 | 5.79 | 5.45 | 5.68 | 1.69 | 11.72 | 966 | 4915 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.18 | 5.53 | 5.13 | 5.38 | 1.67 | 11.20 | 997 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 4.87 | 6.22 | 4.82 | 6.18 | 1.26 | 34.82 | 735 | 4689 | 71 |
| medium+nocloudfx | ongudai | chase@30 | 4.89 | 5.10 | 4.84 | 5.04 | 1.34 | 11.31 | 657 | 3837 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.81 | 9.69 | 4.71 | 5.02 | 1.37 | 9.99 | 679 | 2339 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.82 | 9.57 | 4.72 | 4.89 | 1.24 | 20.88 | 480 | 3696 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.41 | 36.56 | 13.33 | 14.24 | 1.22 | 31.55 | 10.01 | 805 |
| high | ongudai | cockpit@2 | 16.50 | 37.72 | 10.93 | 12.26 | 1.26 | 49.20 | 9.61 | 764 |
| high | ongudai | chase@30 | 15.76 | 35.74 | 13.57 | 14.83 | 1.34 | 28.15 | 8.47 | 993 |
| high | ongudai | chase@60 | 15.37 | 43.67 | 11.75 | 12.63 | 1.35 | 27.27 | 9.90 | 1016 |
| medium | ongudai | cockpit@2 | 15.13 | 35.03 | 8.76 | 9.10 | 1.13 | 28.42 | 10.24 | 504 |
| medium | ongudai | cockpit@2 | 15.24 | 36.64 | 8.76 | 9.02 | 1.14 | 28.26 | 9.12 | 504 |
| medium | ongudai | chase@30 | 14.02 | 26.92 | 9.29 | 9.58 | 1.21 | 27.21 | 8.45 | 681 |
| medium | ongudai | chase@60 | 14.14 | 36.37 | 9.13 | 9.82 | 1.19 | 25.80 | 10.38 | 696 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nocrosses | +0.26 (+5 %) | +0.44 (+9 %) | -0.69 (-14 %) | +0.00 | -0 |
| noimpostors | -0.19 (-4 %) | -0.20 (-4 %) | -0.92 (-19 %) | -0.44 | -9 |

Шум (base2 − base): +0.12, -0.03, -0.82 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nocrosses | +0.30 (+6 %) | +0.40 (+8 %) | +0.12 (+3 %) | +0.27 | +6 |
| noimpostors | -0.13 (-3 %) | -0.08 (-2 %) | -0.41 (-9 %) | -0.21 | -4 |

Шум (base2 − base): +0.13, -0.04, +0.12 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.26 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.31 | 3.46 | 3.03 | 3.27 | 62.1 % |
| Render Depth Pre-Pass | 1.09 | 0.67 | 1.21 | 0.99 | 18.8 % |
| Render Directional/SpotLight Shadows | 0.48 | 0.52 | 0.55 | 0.51 | 9.8 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.08 | 0.10 | 2.0 % |
| Render CanvasItems | 0.09 | 0.08 | 0.12 | 0.09 | 1.8 % |
| Glow | 0.09 | 0.09 | 0.05 | 0.07 | 1.4 % |
| Tonemap | 0.07 | 0.07 | 0.04 | 0.06 | 1.1 % |
| Resolve | 0.04 | 0.05 | 0.02 | 0.04 | 0.7 % |
| Render Sky | 0.01 | 0.01 | 0.04 | 0.02 | 0.5 % |
| Resolve MSAA | 0.02 | 0.02 | 0.01 | 0.02 | 0.3 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.01 | 0.02 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.01 | 0.01 | 0.2 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

### medium+nocloudfx / ongudai (всего 4.73 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.15 | 3.40 | 3.14 | 3.23 | 68.3 % |
| Render Depth Pre-Pass | 0.90 | 0.58 | 0.92 | 0.80 | 17.0 % |
| Render Directional/SpotLight Shadows | 0.21 | 0.26 | 0.09 | 0.19 | 3.9 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.11 | 0.11 | 2.3 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.09 | 0.08 | 0.07 | 0.08 | 1.7 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 32 | 43 | 1.34 | 4.86 | 8088 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 848 | 11208 | 13.22 | 24.98 | 497056 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 584 | 7615 | 13.04 | 22.55 | 284964 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 32 | 41 | 1.27 | 3.71 | 8088 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 849 | 10925 | 12.87 | 25.79 | 497056 | 585 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 584 | 7486 | 12.82 | 21.78 | 284964 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 470@0.1/0, 330@0.3/0, 184@0.4/0 |
| high | ongudai | 5674@0.0/0, 342@0.1/0, 224@0.3/0, 176@0.4/0, 53@0.5/0, 100@2.1/0 |
| high | ongudai | 5329@0.0/0, 348@0.1/0, 181@0.3/0, 181@0.4/0, 57@4.5/0, 165@15.4/0, 50@15.5/0, 52@24.5/0, 52@30.1/0 |
| high | ongudai | 5286@0.0/0, 320@0.1/0, 183@0.3/0, 167@0.4/0, 85@0.5/0, 100@4.6/0, 68@15.4/0, 54@20.0/0, 56@24.6/0, 58@39.0/0, 51@44.6/0, 63@62.1/0 |
| medium | ongudai | 437@0.1/0, 306@0.3/0, 184@0.4/0, 63@0.6/0, 54@1.1/0 |
| medium | ongudai | 5261@0.0/0, 322@0.1/0, 188@0.3/0, 170@0.4/0 |
| medium | ongudai | 5253@0.0/0, 390@0.1/0, 162@0.3/0, 163@0.4/0, 88@4.7/0, 50@5.1/0, 223@15.4/0, 125@24.8/0, 51@24.8/0 |
| medium | ongudai | 5245@0.0/0, 320@0.1/0, 186@0.3/0, 153@0.4/0, 51@1.0/0, 132@4.8/0, 66@15.4/0, 74@24.7/0, 57@39.0/0, 127@44.8/0 |

