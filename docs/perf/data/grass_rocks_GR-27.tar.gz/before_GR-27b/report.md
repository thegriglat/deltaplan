## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.27 | 5.96 | 5.22 | 5.57 | 1.64 | 10.30 | 940 | 3656 | 95 |
| high+nocloudfx | ongudai | chase@60 | 5.19 | 5.64 | 5.14 | 5.56 | 1.45 | 9.03 | 962 | 2800 | 96 |
| high+nocloudfx | ongudai | cockpit@2 | 5.05 | 5.39 | 5.00 | 5.28 | 1.12 | 8.88 | 765 | 3691 | 86 |
| medium+nocloudfx | ongudai | chase@30 | 4.72 | 4.92 | 4.67 | 4.82 | 1.45 | 10.52 | 637 | 2892 | 75 |
| medium+nocloudfx | ongudai | chase@60 | 4.82 | 10.31 | 4.71 | 4.88 | 1.43 | 9.07 | 665 | 2334 | 77 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.53 | 4.76 | 4.48 | 4.67 | 1.06 | 8.12 | 466 | 3040 | 71 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 18.68 | 41.88 | 13.23 | 14.32 | 1.25 | 35.19 | 9.82 | 783 |
| high | ongudai | chase@30 | 17.53 | 38.62 | 13.54 | 15.85 | 1.34 | 30.83 | 9.25 | 956 |
| high | ongudai | chase@60 | 17.36 | 35.39 | 10.54 | 11.42 | 1.34 | 29.99 | 9.29 | 984 |
| medium | ongudai | cockpit@2 | 17.82 | 40.21 | 8.68 | 8.99 | 1.14 | 30.83 | 10.28 | 480 |
| medium | ongudai | chase@30 | 16.14 | 29.75 | 9.01 | 9.66 | 1.23 | 25.81 | 9.89 | 656 |
| medium | ongudai | chase@60 | 16.26 | 33.64 | 8.17 | 8.74 | 1.19 | 26.46 | 10.11 | 667 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.50 (-10 %) | -0.03 (-1 %) | -0.88 (-18 %) | -0.47 | -9 |

Шум (base2 − base): -0.01, -0.01, +0.10 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.27 (-6 %) | -0.03 (-1 %) | -0.77 (-17 %) | -0.36 | -8 |

Шум (base2 − base): +0.03, +0.01, +0.09 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.12 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.30 | 3.48 | 2.97 | 3.25 | 63.5 % |
| Render Depth Pre-Pass | 0.77 | 0.64 | 0.76 | 0.72 | 14.1 % |
| Render Directional/SpotLight Shadows | 0.48 | 0.51 | 0.40 | 0.47 | 9.1 % |
| Render 3D Transparent Pass | 0.18 | 0.11 | 0.29 | 0.19 | 3.8 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.09 | 0.10 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.06 | 0.05 | 0.06 | 0.05 | 1.0 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.8 % |
| Resolve MSAA | 0.05 | 0.02 | 0.04 | 0.04 | 0.7 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.05 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |

### medium+nocloudfx / ongudai (всего 4.61 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.16 | 3.42 | 2.92 | 3.17 | 68.7 % |
| Render Depth Pre-Pass | 0.68 | 0.55 | 0.66 | 0.63 | 13.6 % |
| Render Directional/SpotLight Shadows | 0.19 | 0.24 | 0.12 | 0.18 | 3.9 % |
| Render 3D Transparent Pass | 0.16 | 0.11 | 0.26 | 0.18 | 3.8 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.7 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.06 | 0.04 | 0.05 | 0.05 | 1.1 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.9 % |
| Resolve MSAA | 0.04 | 0.02 | 0.04 | 0.04 | 0.8 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 33 | 1.36 | 4.97 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8303 | 13.05 | 25.19 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5652 | 12.90 | 22.27 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 35 | 1.46 | 5.08 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 641 | 8177 | 12.76 | 25.61 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 440 | 5540 | 12.59 | 21.32 | 213723 | 486 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 412@0.1/0, 311@0.3/0, 191@0.4/0, 67@0.5/0, 106@0.6/0, 54@0.7/0, 59@2.1/0 |
| high | ongudai | 5231@0.0/0, 360@0.1/0, 213@0.3/0, 197@0.4/0, 62@0.5/0, 51@0.8/0, 131@4.5/0, 50@5.3/0, 238@15.5/0, 83@15.6/0, 70@23.1/0, 66@24.5/0, 51@29.1/0, 64@30.1/0 |
| high | ongudai | 5410@0.0/0, 324@0.1/0, 191@0.3/0, 175@0.4/0, 89@0.5/0, 78@1.1/0, 68@2.4/0, 202@5.1/0, 57@5.2/0, 68@15.4/0, 53@16.0/0, 54@22.0/0, 54@25.0/0, 51@28.0/0, 58@31.1/0, 63@39.1/0, 56@43.1/0, 152@45.1/0, 60@60.1/0 |
| medium | ongudai | 486@0.1/0, 322@0.3/0, 229@0.4/0, 68@0.5/0, 52@1.0/0, 82@1.1/0 |
| medium | ongudai | 5373@0.0/0, 355@0.1/0, 212@0.3/0, 198@0.4/0, 60@0.5/0, 51@5.1/0, 58@5.3/0, 273@15.4/0, 62@15.6/0, 64@24.3/0 |
| medium | ongudai | 5315@0.0/0, 342@0.1/0, 222@0.3/0, 159@0.4/0, 62@0.5/0, 60@0.8/0, 78@4.8/0, 77@15.4/0, 62@24.8/0, 76@39.1/0, 57@43.1/0, 60@44.8/0, 55@49.0/0, 51@52.1/0 |

