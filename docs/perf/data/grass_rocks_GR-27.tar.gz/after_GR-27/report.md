## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.18 | 5.70 | 5.13 | 5.26 | 1.64 | 10.42 | 940 | 3558 | 95 |
| high+nocloudfx | ongudai | chase@60 | 5.21 | 10.47 | 5.11 | 5.32 | 1.60 | 11.20 | 972 | 2809 | 97 |
| high+nocloudfx | ongudai | cockpit@2 | 4.92 | 5.18 | 4.87 | 5.11 | 1.37 | 9.93 | 765 | 3572 | 86 |
| medium+nocloudfx | ongudai | chase@30 | 4.70 | 5.12 | 4.65 | 4.87 | 1.43 | 10.17 | 637 | 2827 | 75 |
| medium+nocloudfx | ongudai | chase@60 | 4.83 | 8.87 | 4.74 | 5.06 | 1.27 | 9.56 | 655 | 2325 | 77 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.35 | 9.29 | 4.25 | 4.62 | 1.04 | 19.50 | 466 | 2975 | 71 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 18.87 | 38.74 | 13.20 | 14.39 | 1.29 | 34.28 | 11.02 | 783 |
| high | ongudai | chase@30 | 17.86 | 36.38 | 13.36 | 16.24 | 1.43 | 27.86 | 9.85 | 957 |
| high | ongudai | chase@60 | 17.47 | 37.43 | 10.63 | 11.75 | 1.37 | 30.17 | 10.58 | 986 |
| medium | ongudai | cockpit@2 | 17.63 | 39.47 | 8.69 | 9.04 | 1.12 | 37.46 | 10.41 | 481 |
| medium | ongudai | chase@30 | 16.50 | 36.97 | 8.96 | 9.58 | 1.22 | 29.34 | 10.20 | 657 |
| medium | ongudai | chase@60 | 16.16 | 35.65 | 8.15 | 8.64 | 1.20 | 27.63 | 9.80 | 667 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.40 (-8 %) | -0.00 (-0 %) | -0.45 (-9 %) | -0.29 | -6 |

Шум (base2 − base): -0.02, -0.01, -0.16 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.31 (-7 %) | -0.03 (-1 %) | -0.12 (-3 %) | -0.15 | -3 |

Шум (base2 − base): -0.02, -0.00, +0.03 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.08 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.27 | 3.47 | 3.11 | 3.28 | 64.6 % |
| Render Depth Pre-Pass | 0.79 | 0.66 | 0.69 | 0.71 | 14.0 % |
| Render Directional/SpotLight Shadows | 0.45 | 0.48 | 0.39 | 0.44 | 8.7 % |
| Render 3D Transparent Pass | 0.15 | 0.11 | 0.23 | 0.16 | 3.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.06 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.8 % |
| Resolve MSAA | 0.05 | 0.02 | 0.04 | 0.04 | 0.7 % |
| Pack 3D Cluster Elements | 0.03 | 0.03 | 0.6 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |

### medium+nocloudfx / ongudai (всего 4.55 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.15 | 3.46 | 2.69 | 3.10 | 68.1 % |
| Render Depth Pre-Pass | 0.67 | 0.55 | 0.71 | 0.64 | 14.1 % |
| Render Directional/SpotLight Shadows | 0.22 | 0.23 | 0.12 | 0.19 | 4.2 % |
| Render 3D Transparent Pass | 0.14 | 0.11 | 0.21 | 0.16 | 3.4 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.09 | 0.09 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.06 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.9 % |
| Resolve MSAA | 0.04 | 0.02 | 0.04 | 0.04 | 0.8 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 33 | 1.40 | 4.29 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8308 | 13.06 | 25.41 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5647 | 12.89 | 21.89 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 37 | 1.52 | 4.88 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 640 | 8213 | 12.83 | 26.20 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5518 | 12.60 | 21.44 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 465@0.1/0, 290@0.3/0, 202@0.4/0, 77@0.5/0, 81@0.6/0, 76@0.7/0, 52@1.1/0, 78@2.1/0 |
| high | ongudai | 5303@0.0/0, 355@0.1/0, 190@0.3/0, 164@0.4/0, 106@0.5/0, 56@0.9/0, 148@4.6/0, 54@5.1/0, 229@15.5/0, 53@15.6/0, 125@24.6/0, 53@30.1/0 |
| high | ongudai | 5385@0.0/0, 342@0.1/0, 197@0.3/0, 202@0.4/0, 68@0.5/0, 54@1.1/0, 52@1.8/0, 96@4.5/0, 76@15.4/0, 57@15.4/0, 91@24.4/0, 55@24.5/0, 65@39.1/0, 55@41.1/0, 66@44.4/0, 53@60.0/0 |
| medium | ongudai | 514@0.1/0, 304@0.3/0, 190@0.4/0, 74@0.5/0, 84@0.6/0, 64@1.0/0, 65@1.1/0, 74@2.1/0 |
| medium | ongudai | 5254@0.0/0, 376@0.1/0, 218@0.3/0, 206@0.4/0, 61@0.5/0, 68@0.7/0, 53@0.9/0, 54@4.8/0, 210@15.4/0, 57@15.5/0, 110@24.9/0, 78@24.9/0, 51@30.9/0 |
| medium | ongudai | 5293@0.0/0, 349@0.1/0, 177@0.3/0, 186@0.4/0, 67@0.5/0, 69@0.6/0, 52@0.8/0, 56@2.1/0, 160@4.8/0, 58@5.1/0, 69@15.4/0, 93@24.7/0, 52@24.8/0, 56@39.0/0, 50@43.1/0, 74@44.7/0, 51@50.5/0, 52@60.1/0 |

