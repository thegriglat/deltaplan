## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.00 | 5.37 | 4.96 | 5.28 | 1.56 | 9.82 | 965 | 3444 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.19 | 10.04 | 5.09 | 5.28 | 1.71 | 11.58 | 1001 | 2812 | 100 |
| high+nocloudfx | ongudai | cockpit@2 | 5.05 | 5.48 | 5.00 | 5.17 | 1.35 | 18.96 | 778 | 3360 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.48 | 4.79 | 4.43 | 4.58 | 1.18 | 7.96 | 656 | 2759 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.67 | 5.06 | 4.63 | 4.94 | 1.41 | 9.00 | 681 | 2340 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.76 | 21.19 | 4.55 | 4.96 | 1.11 | 42.55 | 478 | 2618 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 15.51 | 35.41 | 12.87 | 14.66 | 1.21 | 33.10 | 9.27 | 802 |
| high | ongudai | chase@30 | 15.25 | 28.18 | 13.05 | 13.77 | 1.37 | 28.35 | 8.68 | 991 |
| high | ongudai | chase@60 | 15.08 | 47.36 | 11.39 | 12.65 | 1.36 | 29.58 | 9.55 | 1015 |
| medium | ongudai | cockpit@2 | 14.58 | 36.16 | 8.53 | 9.16 | 1.12 | 27.16 | 9.32 | 502 |
| medium | ongudai | chase@30 | 13.89 | 29.38 | 9.01 | 9.86 | 1.22 | 26.50 | 8.71 | 680 |
| medium | ongudai | chase@60 | 13.80 | 39.75 | 8.95 | 9.55 | 1.21 | 22.36 | 10.21 | 695 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.42 (-8 %) | -0.03 (-1 %) | -0.62 (-12 %) | -0.36 | -7 |

Шум (base2 − base): +0.00, +0.01, -0.19 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.37 (-8 %) | -0.01 (-0 %) | -0.60 (-13 %) | -0.32 | -7 |

Шум (base2 − base): -0.03, +0.00, -0.23 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.05 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.06 | 3.41 | 3.17 | 3.22 | 63.7 % |
| Render Depth Pre-Pass | 0.79 | 0.65 | 0.69 | 0.71 | 14.1 % |
| Render Directional/SpotLight Shadows | 0.47 | 0.51 | 0.38 | 0.45 | 9.0 % |
| Render 3D Transparent Pass | 0.14 | 0.11 | 0.33 | 0.20 | 3.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.08 | 1.5 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.06 | 0.05 | 0.06 | 0.05 | 1.0 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.8 % |
| Resolve MSAA | 0.05 | 0.02 | 0.05 | 0.04 | 0.8 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |

### medium+nocloudfx / ongudai (всего 4.58 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.92 | 3.33 | 3.09 | 3.11 | 67.9 % |
| Render Depth Pre-Pass | 0.69 | 0.57 | 0.64 | 0.63 | 13.8 % |
| Render 3D Transparent Pass | 0.14 | 0.11 | 0.33 | 0.20 | 4.3 % |
| Render Directional/SpotLight Shadows | 0.21 | 0.24 | 0.10 | 0.18 | 3.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.09 | 0.09 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.06 | 0.05 | 0.06 | 0.05 | 1.2 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.9 % |
| Resolve MSAA | 0.05 | 0.02 | 0.05 | 0.04 | 0.8 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.02 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Pre Opaque Render | 0.00 | 0.00 | 0.02 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 32 | 42 | 1.32 | 5.21 | 8088 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 848 | 11055 | 13.04 | 25.03 | 497056 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 500 | 6385 | 12.77 | 22.19 | 244119 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 32 | 46 | 1.43 | 4.61 | 8088 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 854 | 10916 | 12.78 | 26.38 | 497056 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 584 | 7391 | 12.66 | 21.45 | 284964 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 5330@0.0/0, 349@0.1/0, 191@0.3/0, 190@0.4/0 |
| high | ongudai | 5248@0.0/0, 519@0.1/0, 185@0.3/0, 166@0.4/0, 71@0.5/0, 89@0.9/0, 216@15.5/0, 62@24.8/0, 53@30.1/0 |
| high | ongudai | 5288@0.0/0, 346@0.1/0, 204@0.3/0, 192@0.4/0, 56@4.8/0, 67@15.4/0, 60@39.1/0, 50@43.1/0, 58@60.1/0, 53@62.0/0 |
| medium | ongudai | 5346@0.0/0, 344@0.1/0, 172@0.3/0, 155@0.4/0, 57@0.5/0 |
| medium | ongudai | 5283@0.0/0, 532@0.1/0, 191@0.3/0, 153@0.4/0, 51@5.1/0, 134@5.4/0, 218@15.5/0, 60@25.4/0 |
| medium | ongudai | 5259@0.0/0, 344@0.1/0, 194@0.3/0, 147@0.4/0, 64@0.5/0, 59@5.0/0, 52@5.1/0, 70@15.4/0, 51@22.0/0, 174@25.1/0, 59@25.2/0, 72@39.1/0, 51@57.0/0, 52@60.0/0 |

