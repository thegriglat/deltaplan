## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.00 | 5.77 | 4.95 | 5.34 | 1.58 | 12.24 | 965 | 3444 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.15 | 5.54 | 5.11 | 5.44 | 1.50 | 7.67 | 1001 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 5.14 | 10.81 | 5.04 | 5.23 | 1.50 | 19.84 | 779 | 3361 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.47 | 4.64 | 4.42 | 4.55 | 1.40 | 9.94 | 656 | 2759 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.74 | 10.77 | 4.63 | 4.95 | 1.41 | 9.64 | 681 | 2340 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.78 | 18.36 | 4.57 | 4.72 | 1.13 | 44.80 | 479 | 2619 | 67 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.45 | 35.69 | 12.94 | 16.39 | 1.31 | 30.82 | 9.47 | 804 |
| high | ongudai | chase@30 | 15.67 | 32.25 | 13.12 | 14.19 | 1.40 | 28.41 | 10.33 | 992 |
| high | ongudai | chase@60 | 15.10 | 39.76 | 11.34 | 12.11 | 1.40 | 29.57 | 9.32 | 1014 |
| medium | ongudai | cockpit@2 | 15.48 | 32.97 | 8.29 | 8.69 | 1.17 | 29.21 | 9.24 | 503 |
| medium | ongudai | chase@30 | 14.34 | 29.57 | 8.95 | 9.62 | 1.24 | 25.76 | 8.61 | 681 |
| medium | ongudai | chase@60 | 13.77 | 40.85 | 8.85 | 9.20 | 1.19 | 24.98 | 9.79 | 695 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.41 (-8 %) | -0.02 (-0 %) | -0.63 (-13 %) | -0.35 | -7 |

Шум (base2 − base): +0.00, -0.02, +0.17 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.30 (-7 %) | -0.01 (-0 %) | -0.60 (-13 %) | -0.30 | -7 |

Шум (base2 − base): -0.05, -0.03, +0.22 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.01 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.06 | 3.40 | 2.98 | 3.15 | 62.7 % |
| Render Depth Pre-Pass | 0.79 | 0.64 | 0.73 | 0.72 | 14.3 % |
| Render Directional/SpotLight Shadows | 0.47 | 0.53 | 0.40 | 0.47 | 9.3 % |
| Render 3D Transparent Pass | 0.14 | 0.11 | 0.34 | 0.20 | 3.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.06 | 0.05 | 0.06 | 0.05 | 1.1 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.8 % |
| Resolve MSAA | 0.05 | 0.02 | 0.05 | 0.04 | 0.8 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Pre Opaque Render | 0.01 | 0.04 | 0.00 | 0.02 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |

### medium+nocloudfx / ongudai (всего 4.52 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.92 | 3.33 | 2.99 | 3.08 | 68.1 % |
| Render Depth Pre-Pass | 0.68 | 0.56 | 0.56 | 0.60 | 13.3 % |
| Render 3D Transparent Pass | 0.14 | 0.11 | 0.33 | 0.20 | 4.3 % |
| Render Directional/SpotLight Shadows | 0.21 | 0.26 | 0.09 | 0.18 | 4.1 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.09 | 0.09 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.06 | 0.04 | 0.06 | 0.05 | 1.2 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.9 % |
| Resolve MSAA | 0.05 | 0.02 | 0.05 | 0.04 | 0.8 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.02 | 0.02 | 0.01 | 0.02 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 34 | 1.40 | 4.86 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8246 | 12.97 | 25.14 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5626 | 12.84 | 22.01 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 34 | 1.44 | 5.09 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 641 | 8136 | 12.69 | 25.81 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5528 | 12.62 | 21.13 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 5257@0.0/0, 381@0.1/0, 196@0.3/0, 167@0.4/0, 68@0.5/0, 67@0.9/0 |
| high | ongudai | 5307@0.0/0, 339@0.1/0, 202@0.3/0, 158@0.4/0, 70@0.5/0, 128@4.6/0, 66@15.4/0, 72@24.6/0, 58@30.1/0 |
| high | ongudai | 5158@0.0/0, 315@0.1/0, 185@0.3/0, 159@0.4/0, 64@0.5/0, 193@5.1/0, 66@15.4/0, 50@18.9/0, 60@39.1/0, 66@45.0/0, 62@60.1/0 |
| medium | ongudai | 5240@0.0/0, 340@0.1/0, 191@0.3/0, 153@0.4/0 |
| medium | ongudai | 5209@0.0/0, 330@0.1/0, 224@0.3/0, 156@0.4/0, 54@0.5/0, 147@4.7/0, 68@15.4/0, 52@24.6/0 |
| medium | ongudai | 5217@0.0/0, 325@0.1/0, 192@0.3/0, 152@0.4/0, 50@0.5/0, 55@1.1/0, 157@4.7/0, 67@15.4/0, 118@24.6/0, 53@24.7/0, 64@39.1/0, 52@57.0/0, 51@60.1/0, 54@62.1/0 |

