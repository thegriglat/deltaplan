## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.28 | 5.54 | 5.23 | 5.39 | 1.74 | 8.32 | 941 | 3656 | 95 |
| high+nocloudfx | ongudai | chase@60 | 5.29 | 18.74 | 5.10 | 5.37 | 1.58 | 9.21 | 962 | 2801 | 96 |
| high+nocloudfx | ongudai | cockpit@2 | 5.06 | 11.55 | 4.94 | 5.10 | 1.28 | 22.71 | 765 | 3691 | 86 |
| medium+nocloudfx | ongudai | chase@30 | 4.69 | 5.12 | 4.64 | 4.91 | 1.46 | 8.06 | 637 | 2892 | 75 |
| medium+nocloudfx | ongudai | chase@60 | 4.87 | 19.68 | 4.67 | 4.92 | 1.18 | 9.40 | 655 | 2325 | 77 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.47 | 5.01 | 4.42 | 4.88 | 1.31 | 8.61 | 466 | 3040 | 71 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 17.95 | 37.57 | 13.23 | 14.18 | 1.25 | 29.91 | 10.04 | 782 |
| high | ongudai | chase@30 | 17.66 | 38.49 | 13.43 | 16.15 | 1.37 | 31.00 | 9.52 | 956 |
| high | ongudai | chase@60 | 16.78 | 46.17 | 10.50 | 11.55 | 1.33 | 31.26 | 9.42 | 984 |
| medium | ongudai | cockpit@2 | 17.46 | 35.88 | 8.70 | 9.08 | 1.11 | 72.01 | 10.86 | 481 |
| medium | ongudai | chase@30 | 16.04 | 26.26 | 9.05 | 9.52 | 1.20 | 23.30 | 9.41 | 657 |
| medium | ongudai | chase@60 | 15.79 | 37.21 | 8.11 | 8.61 | 1.18 | 28.22 | 9.80 | 666 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.52 (-10 %) | -0.02 (-0 %) | -0.86 (-17 %) | -0.47 | -9 |

Шум (base2 − base): +0.11, +0.01, +0.09 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.39 (-8 %) | -0.02 (-0 %) | -0.79 (-18 %) | -0.40 | -9 |

Шум (base2 − base): +0.02, -0.00, +0.08 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.06 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.27 | 3.50 | 2.99 | 3.25 | 64.2 % |
| Render Depth Pre-Pass | 0.78 | 0.62 | 0.72 | 0.70 | 13.9 % |
| Render Directional/SpotLight Shadows | 0.46 | 0.47 | 0.38 | 0.43 | 8.6 % |
| Render 3D Transparent Pass | 0.19 | 0.11 | 0.30 | 0.20 | 3.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.06 | 0.04 | 0.06 | 0.05 | 1.0 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.8 % |
| Resolve MSAA | 0.05 | 0.02 | 0.04 | 0.04 | 0.7 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.04 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |

### medium+nocloudfx / ongudai (всего 4.57 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.20 | 3.41 | 2.89 | 3.17 | 69.3 % |
| Render Depth Pre-Pass | 0.64 | 0.55 | 0.61 | 0.60 | 13.2 % |
| Render 3D Transparent Pass | 0.17 | 0.11 | 0.26 | 0.18 | 3.9 % |
| Render Directional/SpotLight Shadows | 0.14 | 0.22 | 0.12 | 0.16 | 3.4 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.7 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.06 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Copy Screen Texture | 0.06 | 0.00 | 0.06 | 0.04 | 0.9 % |
| Resolve MSAA | 0.05 | 0.02 | 0.05 | 0.04 | 0.9 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 31 | 1.29 | 3.32 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8407 | 13.22 | 25.58 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5616 | 12.82 | 22.24 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 35 | 1.47 | 5.12 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 640 | 8194 | 12.80 | 25.90 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5544 | 12.66 | 21.44 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 475@0.1/0, 329@0.3/0, 173@0.4/0, 54@0.5/0, 54@0.7/0, 52@1.1/0, 62@2.1/0 |
| high | ongudai | 5381@0.0/0, 350@0.1/0, 190@0.3/0, 183@0.4/0, 96@0.5/0, 102@4.6/0, 217@15.4/0, 70@15.5/0, 142@24.6/0, 61@30.1/0 |
| high | ongudai | 5357@0.0/0, 371@0.1/0, 249@0.3/0, 173@0.4/0, 56@0.5/0, 57@0.7/0, 57@0.8/0, 57@1.0/0, 56@1.1/0, 50@1.2/0, 74@4.8/0, 72@15.4/0, 62@24.8/0, 68@39.0/0, 139@44.9/0, 56@44.9/0, 57@46.0/0, 52@49.0/0, 64@52.1/0, 57@58.1/0, 64@60.1/0 |
| medium | ongudai | 495@0.1/0, 326@0.3/0, 171@0.4/0, 58@0.5/0, 52@0.8/0, 74@0.9/0, 65@1.0/0, 57@1.1/0, 154@1.9/0, 58@2.1/0 |
| medium | ongudai | 5404@0.0/0, 347@0.1/0, 192@0.3/0, 158@0.4/0, 59@0.5/0, 70@0.6/0, 105@4.7/0, 54@5.1/0, 54@8.1/0, 66@11.1/0, 228@15.4/0, 51@15.5/0, 95@24.7/0 |
| medium | ongudai | 5368@0.0/0, 324@0.1/0, 199@0.3/0, 168@0.4/0, 63@0.5/0, 59@1.0/0, 60@1.1/0, 149@4.8/0, 64@5.1/0, 67@15.4/0, 81@24.7/0, 65@39.1/0, 141@44.8/0, 65@50.4/0, 59@60.1/0 |

