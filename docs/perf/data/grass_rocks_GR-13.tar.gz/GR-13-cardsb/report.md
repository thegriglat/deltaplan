## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.02 | 5.33 | 4.97 | 5.23 | 1.56 | 10.95 | 966 | 3603 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.12 | 5.41 | 5.07 | 5.27 | 1.52 | 11.38 | 1001 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 4.78 | 4.94 | 4.73 | 4.85 | 1.34 | 8.83 | 780 | 3519 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.45 | 4.66 | 4.41 | 4.64 | 1.14 | 8.60 | 601 | 2836 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.78 | 10.80 | 4.67 | 4.95 | 1.23 | 10.30 | 644 | 2336 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.21 | 4.72 | 4.16 | 4.30 | 1.34 | 12.41 | 423 | 2695 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.18 | 35.80 | 12.67 | 13.48 | 1.23 | 31.58 | 9.17 | 804 |
| high | ongudai | chase@30 | 15.52 | 34.64 | 13.07 | 14.41 | 1.35 | 30.67 | 10.55 | 992 |
| high | ongudai | chase@60 | 15.13 | 39.13 | 11.36 | 12.34 | 1.37 | 25.06 | 10.67 | 1015 |
| medium | ongudai | cockpit@2 | 14.35 | 32.93 | 8.31 | 9.07 | 0.93 | 32.52 | 10.43 | 447 |
| medium | ongudai | chase@30 | 14.22 | 31.16 | 8.87 | 9.21 | 1.18 | 26.63 | 8.73 | 620 |
| medium | ongudai | chase@60 | 14.30 | 39.13 | 8.84 | 9.51 | 1.20 | 24.70 | 10.18 | 662 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.46 (-9 %) | -0.02 (-0 %) | -0.16 (-3 %) | -0.21 | -4 |

Шум (base2 − base): +0.12, +0.00, -0.22 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.26 (-6 %) | -0.00 (-0 %) | -0.21 (-5 %) | -0.16 | -4 |

Шум (base2 − base): +0.02, +0.01, -0.03 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.95 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.08 | 3.38 | 2.85 | 3.10 | 62.8 % |
| Render Depth Pre-Pass | 0.81 | 0.66 | 0.80 | 0.76 | 15.3 % |
| Render Directional/SpotLight Shadows | 0.45 | 0.53 | 0.41 | 0.46 | 9.3 % |
| Render 3D Transparent Pass | 0.16 | 0.11 | 0.36 | 0.21 | 4.3 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.05 | 0.05 | 0.06 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| Pre Opaque Render | 0.01 | 0.01 | 0.00 | 0.01 | 0.1 % |

### medium+nocloudfx / ongudai (всего 4.42 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.94 | 3.34 | 2.69 | 2.99 | 67.7 % |
| Render Depth Pre-Pass | 0.78 | 0.59 | 0.69 | 0.68 | 15.5 % |
| Render 3D Transparent Pass | 0.15 | 0.11 | 0.29 | 0.18 | 4.2 % |
| Render Directional/SpotLight Shadows | 0.15 | 0.24 | 0.09 | 0.16 | 3.7 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 2.0 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.08 | 1.7 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.04 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.5 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Pack 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 36 | 1.51 | 4.86 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8325 | 13.09 | 25.62 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5644 | 12.89 | 22.15 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 33 | 1.36 | 3.45 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 641 | 8269 | 12.90 | 25.70 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5532 | 12.63 | 21.30 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 524@0.1/0, 324@0.3/0, 166@0.4/0, 59@0.5/0 |
| high | ongudai | 5308@0.0/0, 318@0.1/0, 184@0.3/0, 155@0.4/0, 73@0.5/0, 52@0.9/0, 169@5.1/0, 225@15.4/0, 77@25.1/0, 64@30.1/0 |
| high | ongudai | 5301@0.0/0, 352@0.1/0, 210@0.3/0, 156@0.4/0, 66@0.5/0, 53@0.8/0, 59@4.9/0, 52@5.1/0, 66@15.4/0, 144@25.0/0, 60@39.1/0, 125@44.9/0, 54@60.1/0 |
| medium | ongudai | 459@0.1/0, 295@0.3/0, 175@0.4/0, 54@1.0/0 |
| medium | ongudai | 5161@0.0/0, 311@0.1/0, 188@0.3/0, 146@0.4/0, 52@3.7/0, 58@4.4/0, 53@5.1/0, 219@15.4/0, 116@24.4/0 |
| medium | ongudai | 5210@0.0/0, 310@0.1/0, 181@0.3/0, 149@0.4/0, 94@4.6/0, 52@5.1/0, 68@15.4/0, 58@24.6/0, 74@39.1/0, 58@43.1/0 |

