## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 4.95 | 5.19 | 4.90 | 5.02 | 1.44 | 10.90 | 966 | 3444 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.13 | 5.53 | 5.08 | 5.24 | 1.46 | 12.50 | 1001 | 2812 | 98 |
| high+nocloudfx | ongudai | cockpit@2 | 4.50 | 4.89 | 4.45 | 4.81 | 1.30 | 10.25 | 780 | 3361 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.41 | 4.62 | 4.36 | 4.51 | 1.20 | 7.33 | 657 | 2759 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.77 | 5.11 | 4.73 | 5.04 | 1.41 | 11.39 | 681 | 2340 | 78 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.16 | 13.63 | 4.01 | 4.17 | 1.00 | 12.38 | 480 | 2619 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 15.97 | 33.34 | 12.46 | 13.17 | 1.24 | 30.17 | 10.89 | 805 |
| high | ongudai | chase@30 | 15.15 | 24.49 | 12.98 | 14.35 | 1.32 | 27.08 | 8.62 | 992 |
| high | ongudai | chase@60 | 14.67 | 44.42 | 11.22 | 11.95 | 1.30 | 29.61 | 9.22 | 1015 |
| medium | ongudai | cockpit@2 | 14.75 | 32.48 | 8.14 | 8.50 | 1.09 | 33.26 | 9.84 | 504 |
| medium | ongudai | chase@30 | 14.01 | 41.75 | 8.86 | 9.41 | 1.22 | 35.28 | 8.83 | 681 |
| medium | ongudai | chase@60 | 13.99 | 45.45 | 8.72 | 9.17 | 1.17 | 25.56 | 10.72 | 695 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.32 (-7 %) | +0.02 (+0 %) | +0.11 (+3 %) | -0.06 | -1 |

Шум (base2 − base): +0.15, +0.01, -0.20 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.24 (-6 %) | -0.01 (-0 %) | +0.08 (+2 %) | -0.06 | -1 |

Шум (base2 − base): +0.14, +0.01, -0.20 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.83 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.12 | 3.41 | 2.75 | 3.09 | 64.0 % |
| Render Depth Pre-Pass | 0.78 | 0.66 | 0.79 | 0.74 | 15.4 % |
| Render Directional/SpotLight Shadows | 0.43 | 0.51 | 0.34 | 0.43 | 8.8 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.20 | 0.14 | 2.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.09 | 0.03 | 0.7 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

### medium+nocloudfx / ongudai (всего 4.38 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.92 | 3.40 | 2.75 | 3.02 | 69.0 % |
| Render Depth Pre-Pass | 0.64 | 0.57 | 0.65 | 0.62 | 14.2 % |
| Render Directional/SpotLight Shadows | 0.22 | 0.26 | 0.11 | 0.19 | 4.4 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.19 | 0.14 | 3.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 2.0 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.5 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Pre Opaque Render | 0.02 | 0.00 | 0.00 | 0.01 | 0.2 % |
| Pack 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 36 | 1.50 | 5.01 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8298 | 13.05 | 26.02 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5636 | 12.87 | 21.91 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 36 | 1.48 | 5.16 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 640 | 8246 | 12.88 | 25.87 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5517 | 12.60 | 21.23 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 451@0.1/0, 323@0.3/0, 160@0.4/0, 52@2.1/0 |
| high | ongudai | 5185@0.0/0, 354@0.1/0, 227@0.3/0, 178@0.4/0, 51@0.7/0, 122@4.8/0, 236@15.4/0, 70@24.8/0, 51@30.1/0 |
| high | ongudai | 5327@0.0/0, 341@0.1/0, 186@0.3/0, 184@0.4/0, 53@2.4/0, 56@4.9/0, 78@15.4/0, 50@18.9/0, 143@25.0/0, 74@25.1/0, 64@39.1/0, 53@57.0/0, 62@60.1/0, 52@62.1/0 |
| medium | ongudai | 472@0.1/0, 303@0.3/0, 191@0.4/0, 81@0.5/0, 82@1.0/0 |
| medium | ongudai | 5346@0.0/0, 312@0.1/0, 194@0.3/0, 168@0.4/0, 72@0.5/0, 52@1.0/0, 97@5.1/0, 246@15.4/0, 85@25.1/0, 64@30.1/0, 53@31.1/0 |
| medium | ongudai | 5270@0.0/0, 334@0.1/0, 187@0.3/0, 165@0.4/0, 50@0.8/0, 145@5.0/0, 79@15.4/0, 69@39.1/0, 53@44.9/0, 56@60.1/0, 53@62.0/0 |

