## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 4.94 | 5.38 | 4.90 | 5.26 | 1.72 | 9.32 | 966 | 3444 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.12 | 5.42 | 5.07 | 5.25 | 1.57 | 7.84 | 1001 | 2812 | 98 |
| high+nocloudfx | ongudai | cockpit@2 | 4.47 | 4.65 | 4.42 | 4.54 | 1.28 | 8.99 | 780 | 3361 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.50 | 7.18 | 4.41 | 5.26 | 1.26 | 17.72 | 642 | 2755 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.72 | 5.30 | 4.68 | 5.23 | 1.32 | 12.16 | 664 | 2335 | 75 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.07 | 4.71 | 4.02 | 4.33 | 1.00 | 12.74 | 456 | 2612 | 71 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.30 | 36.81 | 12.48 | 14.16 | 1.25 | 68.24 | 8.93 | 804 |
| high | ongudai | chase@30 | 15.54 | 31.80 | 12.95 | 14.00 | 1.38 | 25.75 | 9.53 | 992 |
| high | ongudai | chase@60 | 15.21 | 46.11 | 11.22 | 12.02 | 1.39 | 30.59 | 10.40 | 1015 |
| medium | ongudai | cockpit@2 | 17.10 | 102.01 | 8.09 | 8.52 | 1.14 | 27.96 | 10.92 | 485 |
| medium | ongudai | chase@30 | 16.07 | 34.59 | 8.91 | 9.95 | 1.40 | 27.90 | 10.42 | 668 |
| medium | ongudai | chase@60 | 15.79 | 59.95 | 8.78 | 9.45 | 1.26 | 25.57 | 9.42 | 683 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.35 (-7 %) | -0.01 (-0 %) | +0.13 (+3 %) | -0.08 | -1 |

Шум (base2 − base): +0.12, +0.01, -0.18 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.19 (-4 %) | +0.03 (+1 %) | -0.00 (-0 %) | -0.05 | -1 |

Шум (base2 − base): +0.04, +0.01, +0.09 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.81 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.10 | 3.38 | 2.72 | 3.07 | 63.8 % |
| Render Depth Pre-Pass | 0.76 | 0.66 | 0.80 | 0.74 | 15.4 % |
| Render Directional/SpotLight Shadows | 0.45 | 0.51 | 0.34 | 0.44 | 9.1 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.19 | 0.14 | 2.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.09 | 0.08 | 0.07 | 0.08 | 1.7 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.04 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Pack 3D Cluster Elements | 0.03 | 0.03 | 0.6 % |
| Render 3D Cluster Elements | 0.03 | 0.03 | 0.6 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |

### medium+nocloudfx / ongudai (всего 4.35 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.08 | 3.36 | 2.72 | 3.05 | 70.2 % |
| Render Depth Pre-Pass | 0.62 | 0.58 | 0.57 | 0.59 | 13.6 % |
| Render Directional/SpotLight Shadows | 0.16 | 0.25 | 0.09 | 0.17 | 3.9 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.19 | 0.14 | 3.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 2.0 % |
| Render CanvasItems | 0.09 | 0.08 | 0.07 | 0.08 | 1.9 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.5 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.02 | 0.01 | 0.01 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 35 | 1.45 | 4.89 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8276 | 13.01 | 25.76 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 439 | 5641 | 12.85 | 21.83 | 213723 | 487 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 34 | 1.40 | 5.38 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 642 | 8101 | 12.62 | 25.75 | 372792 | 581 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5525 | 12.61 | 21.26 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 388@0.1/0, 291@0.3/0, 163@0.4/0, 132@2.0/0, 50@2.0/0, 68@2.1/0 |
| high | ongudai | 5223@0.0/0, 335@0.1/0, 176@0.3/0, 160@0.4/0, 84@0.5/0, 145@4.6/0, 233@15.4/0, 52@24.5/0 |
| high | ongudai | 5259@0.0/0, 310@0.1/0, 188@0.3/0, 188@0.4/0, 56@4.9/0, 69@15.4/0, 137@25.0/0, 69@25.0/0, 57@39.0/0, 50@43.1/0, 51@43.1/0, 80@44.9/0, 57@57.0/0, 58@60.1/0, 50@62.1/0 |
| medium | ongudai | 419@0.1/0, 287@0.3/0, 187@0.4/0, 52@0.5/0, 58@1.0/0, 79@1.0/0, 61@1.1/0, 56@3.0/0, 148@4.0/0 |
| medium | ongudai | 5474@0.0/0, 334@0.1/0, 182@0.3/0, 154@0.4/0, 52@0.5/0, 147@4.4/0, 56@5.4/0, 211@15.4/0, 56@24.3/0 |
| medium | ongudai | 5321@0.0/0, 337@0.1/0, 191@0.3/0, 157@0.4/0, 50@0.5/0, 65@3.0/0, 68@3.1/0, 86@3.2/0, 54@3.3/0, 171@4.1/0, 88@4.2/0, 56@4.3/0, 52@5.1/0, 62@6.2/0, 134@15.4/0, 62@15.5/0, 53@18.1/0, 66@18.1/0, 57@18.3/0, 55@24.0/0, 51@34.7/0, 53@35.1/0, 51@38.1/0, 54@38.1/0, 66@39.1/0, 52@44.0/0, 132@44.1/0, 80@44.1/0, 57@44.2/0, 53@44.3/0, 54@49.8/0, 88@50.0/0, 71@50.1/0, 53@56.1/0, 55@60.1/0, 60@62.1/0, 53@62.1/0 |

