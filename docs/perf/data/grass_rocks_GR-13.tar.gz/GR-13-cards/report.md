## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.03 | 5.25 | 4.98 | 5.14 | 1.51 | 8.13 | 966 | 3603 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.12 | 5.55 | 5.08 | 5.47 | 1.48 | 9.66 | 1001 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 4.78 | 5.02 | 4.74 | 4.87 | 1.23 | 17.34 | 780 | 3519 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.47 | 4.66 | 4.43 | 4.57 | 1.34 | 14.54 | 657 | 2845 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.89 | 16.56 | 4.70 | 5.41 | 1.20 | 10.80 | 679 | 2339 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.33 | 4.55 | 4.28 | 4.44 | 1.02 | 11.87 | 480 | 2704 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.14 | 38.53 | 12.70 | 13.90 | 1.22 | 31.18 | 8.11 | 804 |
| high | ongudai | chase@30 | 15.40 | 30.05 | 13.18 | 16.21 | 1.36 | 25.87 | 8.31 | 992 |
| high | ongudai | chase@60 | 15.00 | 38.98 | 11.30 | 12.08 | 1.34 | 24.73 | 9.96 | 1015 |
| medium | ongudai | cockpit@2 | 15.12 | 42.69 | 8.36 | 9.01 | 1.14 | 29.78 | 8.59 | 504 |
| medium | ongudai | chase@30 | 14.59 | 31.28 | 8.89 | 9.23 | 1.22 | 27.98 | 9.48 | 681 |
| medium | ongudai | chase@60 | 15.38 | 45.65 | 8.92 | 9.87 | 1.31 | 32.17 | 9.65 | 696 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.44 (-9 %) | +0.01 (+0 %) | -0.14 (-3 %) | -0.19 | -4 |

Шум (base2 − base): +0.16, -0.02, -0.21 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.32 (-7 %) | -0.03 (-1 %) | -0.05 (-1 %) | -0.13 | -3 |

Шум (base2 − base): +0.09, -0.03, -0.24 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.95 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.07 | 3.40 | 2.84 | 3.10 | 62.7 % |
| Render Depth Pre-Pass | 0.82 | 0.66 | 0.83 | 0.77 | 15.6 % |
| Render Directional/SpotLight Shadows | 0.45 | 0.53 | 0.40 | 0.46 | 9.3 % |
| Render 3D Transparent Pass | 0.16 | 0.11 | 0.36 | 0.21 | 4.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.07 | 1.5 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

### medium+nocloudfx / ongudai (всего 4.51 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.91 | 3.39 | 2.83 | 3.04 | 67.5 % |
| Render Depth Pre-Pass | 0.73 | 0.58 | 0.80 | 0.70 | 15.6 % |
| Render 3D Transparent Pass | 0.15 | 0.11 | 0.29 | 0.18 | 4.0 % |
| Render Directional/SpotLight Shadows | 0.20 | 0.24 | 0.09 | 0.18 | 4.0 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.09 | 0.08 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.02 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 35 | 1.46 | 4.85 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 637 | 8393 | 13.18 | 25.00 | 372792 | 585 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5644 | 12.88 | 22.08 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 35 | 1.45 | 4.21 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 642 | 8222 | 12.81 | 26.07 | 372792 | 581 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 439 | 5544 | 12.63 | 21.30 | 213723 | 487 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 496@0.1/0, 326@0.3/0, 165@0.4/0, 70@0.5/0, 71@1.1/0, 58@2.1/0 |
| high | ongudai | 5219@0.0/0, 335@0.1/0, 208@0.3/0, 148@0.4/0, 51@0.5/0, 56@1.1/0, 91@5.2/0, 52@10.0/0, 51@13.0/0, 202@15.5/0, 51@16.0/0, 55@22.1/0, 60@25.2/0 |
| high | ongudai | 5222@0.0/0, 347@0.1/0, 211@0.3/0, 170@0.4/0, 73@0.5/0, 107@5.1/0, 68@15.4/0, 59@22.1/0, 78@25.1/0, 58@39.0/0, 51@43.1/0, 147@45.1/0, 61@60.1/0 |
| medium | ongudai | 468@0.1/0, 289@0.3/0, 184@0.4/0, 56@0.9/0, 53@2.4/0 |
| medium | ongudai | 5212@0.0/0, 345@0.1/0, 192@0.3/0, 146@0.4/0, 52@0.5/0, 70@4.6/0, 212@15.4/0, 88@24.6/0 |
| medium | ongudai | 5284@0.0/0, 319@0.1/0, 212@0.3/0, 158@0.4/0, 89@4.7/0, 67@15.4/0, 55@24.7/0, 66@39.1/0, 54@44.7/0, 52@60.1/0 |

