## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- low / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": false, "max_fps": 0, "msaa_3d": 0, "scale_3d": 0.75, "scaling_mode": 1, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 1200.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / altai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | chase@30 | 10.32 | 10.83 | 10.27 | 10.74 | 2.02 | 14.06 | 697 | 3865 | 85 |
| high | ongudai | chase@60 | 10.09 | 11.69 | 10.04 | 11.69 | 1.80 | 12.64 | 751 | 3972 | 90 |
| high | ongudai | cockpit@2 | 12.43 | 14.07 | 12.38 | 14.04 | 1.79 | 15.78 | 486 | 3731 | 81 |
| high+nocloudfx | ongudai | chase@30 | 4.76 | 5.17 | 4.71 | 4.80 | 1.51 | 7.44 | 696 | 3865 | 86 |
| high+nocloudfx | ongudai | chase@60 | 5.08 | 5.33 | 5.04 | 5.14 | 1.56 | 7.13 | 751 | 3972 | 90 |
| high+nocloudfx | ongudai | cockpit@2 | 4.43 | 4.59 | 4.38 | 4.47 | 1.11 | 8.73 | 486 | 3731 | 83 |
| low | ongudai | chase@30 | 3.96 | 4.33 | 3.91 | 4.12 | 1.23 | 7.15 | 393 | 1531 | 45 |
| low | ongudai | chase@60 | 3.96 | 4.14 | 3.91 | 4.05 | 1.24 | 7.10 | 389 | 1563 | 46 |
| low | ongudai | cockpit@2 | 4.19 | 4.45 | 4.14 | 4.34 | 1.13 | 8.05 | 307 | 1484 | 45 |
| medium | altai | cockpit@2 | 6.07 | 6.47 | 6.02 | 6.26 | 2.03 | 9.47 | 846 | 3321 | 62 |
| medium | ongudai | chase@30 | 8.16 | 8.38 | 8.11 | 8.27 | 2.04 | 11.24 | 669 | 3243 | 69 |
| medium | ongudai | chase@60 | 8.26 | 8.96 | 8.21 | 8.81 | 1.72 | 11.08 | 745 | 3340 | 70 |
| medium | ongudai | cockpit@2 | 5.33 | 5.83 | 5.28 | 5.73 | 1.28 | 8.00 | 480 | 3335 | 45 |
| medium+nocloudfx | ongudai | chase@30 | 4.60 | 4.77 | 4.55 | 4.64 | 1.45 | 6.78 | 668 | 3243 | 69 |
| medium+nocloudfx | ongudai | chase@60 | 5.01 | 5.19 | 4.96 | 5.07 | 1.25 | 12.45 | 745 | 3340 | 70 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.24 | 4.68 | 4.19 | 4.27 | 1.24 | 7.81 | 491 | 3120 | 67 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 14.40 | 27.18 | 13.33 | 14.12 | 0.99 | 25.31 | 10.92 | 495 |
| high | ongudai | cockpit@2 | 14.30 | 27.07 | 13.30 | 14.16 | 1.00 | 24.80 | 9.12 | 495 |
| high | ongudai | cockpit@2 | 14.19 | 22.85 | 13.28 | 14.09 | 0.97 | 21.98 | 8.47 | 495 |
| high | ongudai | chase@30 | 12.07 | 23.46 | 10.22 | 10.94 | 1.14 | 24.19 | 8.93 | 710 |
| high | ongudai | chase@30 | 12.01 | 24.71 | 10.26 | 11.01 | 1.13 | 24.85 | 8.54 | 709 |
| high | ongudai | chase@30 | 12.47 | 36.17 | 10.23 | 10.92 | 1.14 | 24.73 | 8.17 | 710 |
| high | ongudai | chase@60 | 11.70 | 29.51 | 10.03 | 10.51 | 1.11 | 24.29 | 8.87 | 764 |
| high | ongudai | chase@60 | 11.93 | 34.96 | 10.14 | 10.71 | 1.17 | 25.89 | 8.49 | 764 |
| high | ongudai | chase@60 | 12.27 | 37.97 | 10.02 | 10.46 | 1.16 | 25.94 | 9.35 | 761 |
| low | ongudai | cockpit@2 | 10.12 | 24.24 | 4.09 | 4.30 | 0.84 | 26.84 | 9.16 | 322 |
| low | ongudai | cockpit@2 | 10.11 | 21.90 | 4.03 | 4.17 | 0.87 | 24.51 | 10.51 | 321 |
| low | ongudai | chase@30 | 9.62 | 23.38 | 3.90 | 4.08 | 0.92 | 23.01 | 8.69 | 404 |
| low | ongudai | chase@30 | 9.25 | 20.98 | 3.88 | 4.02 | 0.90 | 21.14 | 8.26 | 403 |
| low | ongudai | chase@60 | 9.44 | 27.53 | 3.78 | 3.95 | 0.91 | 21.64 | 13.85 | 399 |
| low | ongudai | chase@60 | 9.92 | 26.11 | 3.73 | 3.88 | 0.91 | 19.49 | 12.10 | 400 |
| medium | altai | cockpit@2 | 10.89 | 25.37 | 5.79 | 6.09 | 1.26 | 25.31 | 8.61 | 877 |
| medium | altai | cockpit@2 | 10.69 | 25.07 | 5.77 | 6.08 | 1.25 | 30.49 | 8.71 | 877 |
| medium | ongudai | cockpit@2 | 7.64 | 15.10 | 7.31 | 8.58 | 0.89 | 17.23 | 4.66 | 491 |
| medium | ongudai | cockpit@2 | 10.97 | 21.56 | 8.68 | 9.09 | 0.97 | 21.15 | 8.57 | 497 |
| medium | ongudai | cockpit@2 | 10.88 | 22.09 | 8.77 | 9.23 | 0.97 | 21.49 | 8.78 | 496 |
| medium | ongudai | chase@30 | 10.60 | 29.19 | 8.43 | 8.82 | 1.08 | 26.48 | 7.46 | 680 |
| medium | ongudai | chase@30 | 10.79 | 22.02 | 8.41 | 8.75 | 1.09 | 23.70 | 9.15 | 680 |
| medium | ongudai | chase@30 | 10.65 | 25.53 | 8.43 | 8.80 | 1.10 | 24.81 | 8.59 | 680 |
| medium | ongudai | chase@60 | 10.49 | 31.48 | 8.38 | 8.73 | 1.08 | 25.05 | 8.11 | 757 |
| medium | ongudai | chase@60 | 10.64 | 33.32 | 8.38 | 8.74 | 1.12 | 24.86 | 8.56 | 757 |
| medium | ongudai | chase@60 | 10.79 | 35.20 | 8.40 | 8.74 | 1.10 | 24.39 | 8.40 | 756 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| scale50 | -2.45 (-24 %) | -2.14 (-21 %) | -4.79 (-39 %) | -3.13 | -28 |
| scale75 | -1.02 (-10 %) | -1.77 (-18 %) | -3.21 (-26 %) | -2.00 | -18 |
| nomsaa | -0.26 (-2 %) | -0.47 (-5 %) | -0.46 (-4 %) | -0.39 | -4 |
| noshadow | -0.72 (-7 %) | -1.09 (-11 %) | -0.69 (-6 %) | -0.83 | -8 |
| shadow1k | -0.32 (-3 %) | -0.57 (-6 %) | -0.37 (-3 %) | -0.42 | -4 |
| noglow | -0.13 (-1 %) | -0.23 (-2 %) | -0.12 (-1 %) | -0.16 | -1 |
| nocloudfx | -5.58 (-54 %) | -5.00 (-50 %) | -8.00 (-65 %) | -6.19 | -56 |
| noclouds | -5.64 (-55 %) | -5.04 (-50 %) | -8.06 (-65 %) | -6.25 | -57 |
| notrees | -0.14 (-1 %) | -0.44 (-4 %) | +0.23 (+2 %) | -0.12 | -1 |
| notreeshadow | -0.30 (-3 %) | -0.55 (-5 %) | +0.30 (+2 %) | -0.18 | -2 |
| noimpostors | -0.07 (-1 %) | -0.29 (-3 %) | -0.05 (-0 %) | -0.14 | -1 |
| nograss | -1.16 (-11 %) | -1.24 (-12 %) | -1.04 (-8 %) | -1.15 | -11 |
| noscatter | -0.21 (-2 %) | -0.34 (-3 %) | -0.42 (-3 %) | -0.32 | -3 |
| noobjects | +0.00 (+0 %) | -0.17 (-2 %) | +0.15 (+1 %) | -0.00 | -0 |
| nohaze | -0.04 (-0 %) | -0.22 (-2 %) | +0.05 (+0 %) | -0.07 | -1 |
| noterrain | -1.48 (-14 %) | -1.91 (-19 %) | -1.03 (-8 %) | -1.48 | -14 |
| cloudres33 | -0.94 (-9 %) | -0.82 (-8 %) | -3.26 (-26 %) | -1.68 | -15 |
| cloudres25 | -1.11 (-11 %) | -0.61 (-6 %) | -3.58 (-29 %) | -1.77 | -15 |
| cloudit64 | -1.64 (-16 %) | -1.60 (-16 %) | -1.91 (-15 %) | -1.72 | -16 |
| cloudlight3 | -0.17 (-2 %) | -0.48 (-5 %) | +0.17 (+1 %) | -0.16 | -2 |
| clouddetail0 | -0.29 (-3 %) | -0.62 (-6 %) | +0.02 (+0 %) | -0.30 | -3 |

Шум (base2 − base): +0.04, -0.24, +0.25 мс

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| scale50 | -1.27 (-27 %) | -1.42 (-28 %) | -1.09 (-25 %) | -1.26 | -27 |
| scale75 | -0.71 (-15 %) | -0.79 (-16 %) | -0.59 (-14 %) | -0.70 | -15 |
| nomsaa | -0.25 (-5 %) | -0.29 (-6 %) | -0.26 (-6 %) | -0.26 | -6 |
| noshadow | -0.69 (-15 %) | -0.91 (-18 %) | -0.47 (-11 %) | -0.69 | -15 |
| shadow1k | -0.28 (-6 %) | -0.38 (-8 %) | -0.12 (-3 %) | -0.26 | -5 |
| noglow | -0.14 (-3 %) | -0.16 (-3 %) | -0.12 (-3 %) | -0.14 | -3 |
| notrees | -0.13 (-3 %) | -0.50 (-10 %) | -0.05 (-1 %) | -0.23 | -5 |
| notreeshadow | -0.31 (-7 %) | -0.52 (-10 %) | -0.04 (-1 %) | -0.29 | -6 |
| noimpostors | -0.12 (-3 %) | -0.14 (-3 %) | -0.16 (-4 %) | -0.14 | -3 |
| nograss | -1.18 (-25 %) | -1.11 (-22 %) | -1.17 (-27 %) | -1.15 | -25 |
| noscatter | -0.25 (-5 %) | -0.24 (-5 %) | -0.44 (-10 %) | -0.31 | -7 |
| noobjects | -0.03 (-1 %) | -0.01 (-0 %) | -0.00 (-0 %) | -0.02 | -0 |
| nohaze | -0.10 (-2 %) | -0.09 (-2 %) | -0.07 (-2 %) | -0.09 | -2 |
| noterrain | -1.48 (-32 %) | -1.76 (-35 %) | -1.19 (-27 %) | -1.48 | -31 |

Шум (base2 − base): +0.01, +0.04, -0.01 мс

### low / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| scale50 | -0.47 (-12 %) | -0.61 (-16 %) | -0.71 (-17 %) | -0.59 | -15 |
| scale75 | +0.14 (+4 %) | -0.02 (-0 %) | -0.09 (-2 %) | +0.01 | +0 |
| nomsaa | +0.14 (+4 %) | -0.09 (-2 %) | -0.16 (-4 %) | -0.03 | -1 |
| noshadow | -0.17 (-4 %) | -0.27 (-7 %) | -0.62 (-15 %) | -0.35 | -9 |
| shadow1k | +0.04 (+1 %) | -0.19 (-5 %) | -0.29 (-7 %) | -0.15 | -4 |
| noglow | +0.09 (+2 %) | -0.10 (-2 %) | -0.13 (-3 %) | -0.05 | -1 |
| nocloudfx | -1.55 (-40 %) | -1.41 (-36 %) | -1.78 (-43 %) | -1.58 | -40 |
| noclouds | -1.62 (-41 %) | -1.43 (-37 %) | -1.82 (-44 %) | -1.62 | -41 |
| notrees | -0.08 (-2 %) | -0.34 (-9 %) | -0.28 (-7 %) | -0.23 | -6 |
| notreeshadow | +0.16 (+4 %) | +0.01 (+0 %) | -0.03 (-1 %) | +0.05 | +1 |
| noimpostors | -0.07 (-2 %) | -0.19 (-5 %) | -0.30 (-7 %) | -0.19 | -5 |
| nograss | +0.14 (+4 %) | +0.01 (+0 %) | -0.03 (-1 %) | +0.04 | +1 |
| noscatter | -0.27 (-7 %) | -0.17 (-4 %) | -0.52 (-13 %) | -0.32 | -8 |
| noobjects | -0.12 (-3 %) | -0.01 (-0 %) | -0.07 (-2 %) | -0.07 | -2 |
| nohaze | -0.13 (-3 %) | -0.03 (-1 %) | -0.11 (-3 %) | -0.09 | -2 |
| noterrain | -0.96 (-24 %) | -1.11 (-28 %) | -0.82 (-20 %) | -0.96 | -24 |
| cloudres33 | -0.05 (-1 %) | +0.01 (+0 %) | -0.09 (-2 %) | -0.04 | -1 |
| cloudres25 | -0.03 (-1 %) | -0.11 (-3 %) | -0.20 (-5 %) | -0.11 | -3 |
| cloudit64 | -0.04 (-1 %) | +0.01 (+0 %) | -0.04 (-1 %) | -0.02 | -1 |
| cloudlight3 | -0.04 (-1 %) | -0.07 (-2 %) | -0.04 (-1 %) | -0.05 | -1 |
| clouddetail0 | -0.01 (-0 %) | -0.09 (-2 %) | -0.04 (-1 %) | -0.04 | -1 |

Шум (base2 − base): -0.13, -0.16, -0.08 мс

### medium / altai

| опыт | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|
| scale50 | -1.37 (-23 %) | -1.37 | -23 |
| scale75 | -0.90 (-15 %) | -0.90 | -15 |
| nomsaa | -0.43 (-7 %) | -0.43 | -7 |
| noshadow | -0.47 (-8 %) | -0.47 | -8 |
| shadow1k | -0.29 (-5 %) | -0.29 | -5 |
| noglow | -0.24 (-4 %) | -0.24 | -4 |
| nocloudfx | -1.96 (-33 %) | -1.96 | -33 |
| noclouds | -2.03 (-34 %) | -2.03 | -34 |
| notrees | -0.00 (-0 %) | -0.00 | -0 |
| notreeshadow | +0.21 (+3 %) | +0.21 | +3 |
| noimpostors | -0.32 (-5 %) | -0.32 | -5 |
| nograss | -1.02 (-17 %) | -1.02 | -17 |
| noscatter | -0.05 (-1 %) | -0.05 | -1 |
| noobjects | -0.13 (-2 %) | -0.13 | -2 |
| nohaze | -0.20 (-3 %) | -0.20 | -3 |
| noterrain | -1.42 (-24 %) | -1.42 | -24 |
| cloudres33 | -0.10 (-2 %) | -0.10 | -2 |
| cloudres25 | -0.08 (-1 %) | -0.08 | -1 |
| cloudit64 | -0.37 (-6 %) | -0.37 | -6 |
| cloudlight3 | -0.07 (-1 %) | -0.07 | -1 |
| clouddetail0 | -0.04 (-1 %) | -0.04 | -1 |

Шум (base2 − base): -0.12 мс

### medium / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| scale50 | -1.11 (-14 %) | -1.69 (-21 %) | -1.36 (-26 %) | -1.39 | -20 |
| scale75 | -1.07 (-13 %) | -1.08 (-13 %) | -0.84 (-16 %) | -1.00 | -14 |
| nomsaa | -0.56 (-7 %) | -0.11 (-1 %) | +0.43 (+8 %) | -0.08 | -0 |
| noshadow | -1.06 (-13 %) | -1.00 (-12 %) | -0.64 (-12 %) | -0.90 | -12 |
| shadow1k | -0.63 (-8 %) | -0.64 (-8 %) | -0.27 (-5 %) | -0.51 | -7 |
| noglow | -0.18 (-2 %) | -0.30 (-4 %) | -0.28 (-5 %) | -0.25 | -4 |
| nocloudfx | -3.56 (-44 %) | -3.26 (-40 %) | -1.26 (-24 %) | -2.69 | -36 |
| noclouds | -3.64 (-45 %) | -3.31 (-40 %) | -1.32 (-25 %) | -2.75 | -37 |
| notrees | -0.15 (-2 %) | -0.66 (-8 %) | -0.19 (-4 %) | -0.33 | -5 |
| notreeshadow | -0.65 (-8 %) | -0.77 (-9 %) | -0.21 (-4 %) | -0.54 | -7 |
| noimpostors | -0.36 (-4 %) | -0.27 (-3 %) | -0.29 (-5 %) | -0.31 | -4 |
| nograss | -1.21 (-15 %) | -0.98 (-12 %) | -0.97 (-18 %) | -1.05 | -15 |
| noscatter | -0.53 (-6 %) | -0.37 (-4 %) | -0.57 (-11 %) | -0.49 | -7 |
| noobjects | -0.31 (-4 %) | -0.22 (-3 %) | -0.14 (-3 %) | -0.22 | -3 |
| nohaze | -0.34 (-4 %) | -0.23 (-3 %) | -0.23 (-4 %) | -0.27 | -4 |
| noterrain | -1.71 (-21 %) | -1.82 (-22 %) | -1.42 (-27 %) | -1.65 | -23 |
| cloudres33 | +0.14 (+2 %) | -0.16 (-2 %) | -0.14 (-3 %) | -0.05 | -1 |
| cloudres25 | +0.36 (+4 %) | -0.37 (-5 %) | -0.18 (-3 %) | -0.06 | -1 |
| cloudit64 | -0.94 (-12 %) | -1.08 (-13 %) | -0.30 (-6 %) | -0.77 | -10 |
| cloudlight3 | -0.39 (-5 %) | -0.28 (-3 %) | -0.10 (-2 %) | -0.26 | -3 |
| clouddetail0 | -0.30 (-4 %) | -0.30 (-4 %) | -0.13 (-2 %) | -0.24 | -3 |

Шум (base2 − base): -0.55, -0.27, -0.23 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| scale50 | -1.32 (-29 %) | -1.48 (-30 %) | -1.11 (-26 %) | -1.31 | -29 |
| scale75 | -0.73 (-16 %) | -0.82 (-16 %) | -0.63 (-15 %) | -0.73 | -16 |
| nomsaa | -0.26 (-6 %) | -0.30 (-6 %) | -0.26 (-6 %) | -0.27 | -6 |
| noshadow | -0.73 (-16 %) | -1.00 (-20 %) | -0.53 (-13 %) | -0.75 | -16 |
| shadow1k | -0.34 (-7 %) | -0.48 (-10 %) | -0.10 (-2 %) | -0.31 | -6 |
| noglow | -0.13 (-3 %) | -0.13 (-3 %) | -0.13 (-3 %) | -0.13 | -3 |
| notrees | -0.29 (-6 %) | -0.72 (-14 %) | -0.13 (-3 %) | -0.38 | -8 |
| notreeshadow | -0.36 (-8 %) | -0.62 (-13 %) | -0.06 (-2 %) | -0.35 | -7 |
| noimpostors | -0.08 (-2 %) | -0.11 (-2 %) | -0.16 (-4 %) | -0.12 | -3 |
| nograss | -0.91 (-20 %) | -0.85 (-17 %) | -0.92 (-22 %) | -0.90 | -20 |
| noscatter | -0.26 (-6 %) | -0.22 (-4 %) | -0.51 (-12 %) | -0.33 | -7 |
| noobjects | -0.04 (-1 %) | -0.03 (-1 %) | -0.02 (-1 %) | -0.03 | -1 |
| nohaze | -0.09 (-2 %) | -0.07 (-2 %) | -0.08 (-2 %) | -0.08 | -2 |
| noterrain | -1.58 (-35 %) | -1.79 (-36 %) | -1.22 (-29 %) | -1.53 | -33 |

Шум (base2 − base): -0.01, -0.00, -0.03 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high / ongudai (всего 10.89 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Process Post Transparent Compositor Effects | 5.55 | 5.14 | 7.88 | 6.19 | 56.8 % |
| Render Opaque Pass | 2.68 | 2.88 | 2.48 | 2.68 | 24.6 % |
| Render Depth Pre-Pass | 1.03 | 1.00 | 1.11 | 1.05 | 9.6 % |
| Render Directional/SpotLight Shadows | 0.53 | 0.68 | 0.34 | 0.52 | 4.7 % |
| Render 3D Transparent Pass | 0.09 | 0.09 | 0.10 | 0.09 | 0.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 0.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 0.7 % |
| Render CanvasItems | 0.06 | 0.06 | 0.05 | 0.05 | 0.5 % |
| Resolve | 0.04 | 0.05 | 0.05 | 0.05 | 0.4 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.2 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.02 | 0.01 | 0.1 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.01 | 0.01 | 0.0 % |

### high+nocloudfx / ongudai (всего 4.71 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.69 | 2.88 | 2.49 | 2.69 | 57.1 % |
| Render Depth Pre-Pass | 1.08 | 0.96 | 1.14 | 1.06 | 22.5 % |
| Render Directional/SpotLight Shadows | 0.49 | 0.71 | 0.31 | 0.51 | 10.7 % |
| Render 3D Transparent Pass | 0.09 | 0.09 | 0.10 | 0.09 | 2.0 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Render CanvasItems | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| Setup 3D Scene | 0.00 | 0.00 | 0.00 | 0.00 | 0.1 % |

### low / ongudai (всего 4.06 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Process Post Transparent Compositor Effects | 1.62 | 1.52 | 1.80 | 1.64 | 40.5 % |
| Render Opaque Pass | 1.50 | 1.66 | 1.34 | 1.50 | 37.0 % |
| Render Depth Pre-Pass | 0.41 | 0.41 | 0.47 | 0.43 | 10.6 % |
| Render Directional/SpotLight Shadows | 0.16 | 0.12 | 0.29 | 0.19 | 4.7 % |
| Tonemap | 0.11 | 0.11 | 0.11 | 0.11 | 2.7 % |
| Render 3D Transparent Pass | 0.06 | 0.05 | 0.06 | 0.06 | 1.4 % |
| Render CanvasItems | 0.06 | 0.06 | 0.05 | 0.05 | 1.3 % |
| Copy Depth Texture | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.2 % |
| > Bake 3D Cluster | 0.00 | 0.00 | 0.01 | 0.01 | 0.1 % |
| Pre Opaque Render | 0.00 | 0.00 | 0.01 | 0.00 | 0.1 % |
| Setup 3D Scene | 0.00 | 0.00 | 0.00 | 0.00 | 0.1 % |
| Cull CanvasItem Tree | 0.00 | 0.00 | 0.00 | 0.00 | 0.0 % |

### medium / altai (всего 6.08 мс)

| проход | cockpit@2 | среднее | доля |
|---|---|---|---|
| Render Opaque Pass | 2.33 | 2.33 | 38.3 % |
| Process Post Transparent Compositor Effects | 2.03 | 2.03 | 33.3 % |
| Render Depth Pre-Pass | 0.96 | 0.96 | 15.8 % |
| Render Directional/SpotLight Shadows | 0.33 | 0.33 | 5.4 % |
| Render 3D Transparent Pass | 0.11 | 0.11 | 1.8 % |
| Glow | 0.09 | 0.09 | 1.4 % |
| Tonemap | 0.07 | 0.07 | 1.2 % |
| Resolve | 0.04 | 0.04 | 0.7 % |
| Resolve MSAA | 0.02 | 0.02 | 0.3 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.3 % |
| Render Sky | 0.02 | 0.02 | 0.3 % |
| Setup Shadows | 0.02 | 0.02 | 0.3 % |
| Render CanvasItems | 0.01 | 0.01 | 0.2 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.1 % |

### medium / ongudai (всего 7.38 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Process Post Transparent Compositor Effects | 3.85 | 3.39 | 1.18 | 2.81 | 38.0 % |
| Render Opaque Pass | 2.57 | 2.80 | 2.37 | 2.58 | 34.9 % |
| Render Depth Pre-Pass | 0.90 | 0.88 | 0.94 | 0.90 | 12.3 % |
| Render Directional/SpotLight Shadows | 0.62 | 0.81 | 0.44 | 0.62 | 8.5 % |
| Render 3D Transparent Pass | 0.10 | 0.09 | 0.11 | 0.10 | 1.4 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.2 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 0.9 % |
| Render CanvasItems | 0.06 | 0.06 | 0.05 | 0.05 | 0.7 % |
| Resolve | 0.04 | 0.04 | 0.05 | 0.05 | 0.6 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.3 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Render Sky | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |

### medium+nocloudfx / ongudai (всего 4.58 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.58 | 2.81 | 2.33 | 2.57 | 56.2 % |
| Render Depth Pre-Pass | 0.91 | 0.85 | 0.95 | 0.90 | 19.7 % |
| Render Directional/SpotLight Shadows | 0.60 | 0.85 | 0.47 | 0.64 | 14.0 % |
| Render 3D Transparent Pass | 0.09 | 0.09 | 0.10 | 0.09 | 2.0 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Render CanvasItems | 0.06 | 0.06 | 0.05 | 0.06 | 1.2 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Setup Shadows | 0.01 | 0.01 | 0.02 | 0.02 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| Setup 3D Scene | 0.00 | 0.00 | 0.00 | 0.00 | 0.1 % |

## Пересчёт поля воздуха в полёте (без паузы)

| пресет | место | состояние | кадров | кадр, мс | 1%-худших, мс | GPU окна, мс | доля кадров с занятым AirRuntime | стена пересчёта, с |
|---|---|---|---|---|---|---|---|---|
| high | ongudai | air_busy | 616 | 13.13 | 53.37 | 9.27 | 89 % | 8.117311 |
| high | ongudai | air_idle | 249 | 12.13 | 33.93 | 9.98 | 0 % | — |
| low | ongudai | air_busy | 628 | 11.25 | 45.88 | 3.82 | 92 % | 7.088605 |
| low | ongudai | air_idle | 312 | 9.64 | 31.59 | 3.62 | 0 % | — |
| medium | altai | air_busy | 6824 | 5.88 | 6.59 | 5.84 | 100 % | 40.35848 |
| medium | altai | air_idle | 482 | 6.23 | 7.67 | 6.18 | 0 % | — |
| medium | ongudai | air_busy | 579 | 12.20 | 55.64 | 7.38 | 95 % | 7.08613 |
| medium | ongudai | air_idle | 289 | 10.40 | 35.34 | 7.97 | 0 % | — |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_fly_air_chunks.jsonl | AirPhaseJob | 12 | 18 | 1.49 | 7.15 | 3033 | 253 |
| high_ongudai_fly_air_chunks.jsonl | AirPicardJob | 362 | 3791 | 10.47 | 20.86 | 155603 | 430 |
| high_ongudai_fly_air_chunks.jsonl | AirWindowJob | 396 | 4010 | 10.13 | 25.65 | 109695 | 277 |
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 48 | 71 | 1.48 | 7.08 | 12132 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 1517 | 20485 | 13.50 | 23.33 | 873630 | 576 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 974 | 13267 | 13.62 | 23.42 | 477900 | 491 |
| low_ongudai_fly_air_chunks.jsonl | AirPhaseJob | 12 | 22 | 1.80 | 6.65 | 3033 | 253 |
| low_ongudai_fly_air_chunks.jsonl | AirPicardJob | 351 | 3592 | 10.23 | 25.52 | 155603 | 443 |
| low_ongudai_fly_air_chunks.jsonl | AirWindowJob | 393 | 3429 | 8.73 | 20.47 | 109695 | 279 |
| low_ongudai_load_air_chunks.jsonl | AirPhaseJob | 25 | 52 | 2.08 | 8.26 | 6066 | 243 |
| low_ongudai_load_air_chunks.jsonl | AirPicardJob | 756 | 9881 | 13.07 | 25.82 | 436815 | 578 |
| low_ongudai_load_air_chunks.jsonl | AirWindowJob | 486 | 6145 | 12.64 | 20.49 | 238950 | 492 |
| medium_altai_fly_air_chunks.jsonl | AirPhaseJob | 8 | 11 | 1.43 | 4.47 | 2022 | 253 |
| medium_altai_fly_air_chunks.jsonl | AirPicardJob | 72 | 764 | 10.61 | 22.56 | 43166 | 600 |
| medium_altai_fly_air_chunks.jsonl | AirWindowJob | 369 | 5374 | 14.56 | 22.80 | 193762 | 525 |
| medium_altai_load_air_chunks.jsonl | AirPhaseJob | 24 | 34 | 1.41 | 7.61 | 6066 | 253 |
| medium_altai_load_air_chunks.jsonl | AirPicardJob | 216 | 2261 | 10.47 | 22.69 | 129498 | 600 |
| medium_altai_load_air_chunks.jsonl | AirWindowJob | 1105 | 16095 | 14.57 | 23.18 | 581286 | 526 |
| medium_ongudai_fly_air_chunks.jsonl | AirPhaseJob | 12 | 16 | 1.35 | 7.02 | 3033 | 253 |
| medium_ongudai_fly_air_chunks.jsonl | AirPicardJob | 346 | 3692 | 10.67 | 23.06 | 155603 | 450 |
| medium_ongudai_fly_air_chunks.jsonl | AirWindowJob | 404 | 3796 | 9.40 | 23.13 | 109695 | 272 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 50 | 101 | 2.02 | 11.62 | 11121 | 222 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 1429 | 20034 | 14.02 | 46.86 | 744400 | 521 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 811 | 10998 | 13.56 | 23.18 | 398250 | 491 |

## CPU: поддеревья Game выключены по очереди (полёт, chase)

Δ — к среднему соседних замеров cpu_base. Шум ±1–2 мс: смотреть только крупное.

| пресет | место | узел (класс) | кадр, мс | Δ кадра, мс | 1%-худших, мс | GPU, мс |
|---|---|---|---|---|---|---|
| high | ongudai | Environment (SkyEnvironment) | 11.16 | -1.42 | 34.45 | 9.13 |
| high | ongudai | Environment/SunClock (SunClock) | 12.73 | +0.34 | 38.42 | 9.12 |
| high | ongudai | Environment/SunGlare (SunGlare) | 11.10 | -1.24 | 30.31 | 9.48 |
| high | ongudai | Terrain (Terrain) | 11.16 | -1.41 | 21.08 | 9.34 |
| high | ongudai | Terrain/Mesh (TerrainRenderer) | 11.89 | -0.65 | 28.95 | 9.65 |
| high | ongudai | Terrain/Trees (TerrainTreeModels) | 12.13 | -0.03 | 34.14 | 10.01 |
| high | ongudai | Terrain/ForestImpostors (ForestImpostors) | 12.01 | -0.33 | 34.66 | 9.90 |
| high | ongudai | Terrain/Grass (GrassField) | 12.38 | -0.25 | 29.02 | 10.29 |
| high | ongudai | Terrain/Wind (TerrainWind) | 11.71 | -0.73 | 23.47 | 10.39 |
| high | ongudai | Terrain/Rocks (RockScatter) | 12.39 | +0.41 | 38.91 | 9.95 |
| high | ongudai | Terrain/Shrubs (ShrubScatter) | 12.59 | +0.48 | 36.87 | 10.53 |
| high | ongudai | Glider (Glider) | 12.87 | +0.08 | 42.47 | 11.53 |
| high | ongudai | Glider/Visual (GliderVisual) | 12.17 | -0.31 | 36.00 | 10.53 |
| high | ongudai | InputController (InputController) | 12.37 | +0.66 | 37.95 | 10.34 |
| high | ongudai | FlightInstrument (FlightInstrument) | 12.51 | +0.48 | 38.44 | 10.12 |
| high | ongudai | InstrumentOverlay (InstrumentOverlay) | 12.17 | +0.26 | 38.70 | 9.95 |
| high | ongudai | InstrumentOverlay/FlightInstrument (FlightInstrument) | 12.28 | +0.89 | 42.29 | 10.00 |
| high | ongudai | VarioAudio (VarioAudio) | 11.67 | +0.33 | 37.63 | 9.94 |
| high | ongudai | FlightAudio (FlightAudio) | 12.14 | +0.88 | 38.87 | 10.14 |
| high | ongudai | WindFieldDebug (WindFieldDebug) | 11.47 | +0.02 | 27.89 | 10.06 |
| high | ongudai | WorldLink (WorldLink) | 11.53 | +0.01 | 27.62 | 9.71 |
| high | ongudai | WorldLink/WorldObjects (WorldObjects) | 11.10 | -0.11 | 34.44 | 9.51 |
| high | ongudai | Bots (BotPilots) | 11.24 | +0.05 | 29.54 | 9.81 |
| high | ongudai | Bots/Bot0 (BotGlider) | 11.61 | +0.23 | 34.97 | 9.69 |
| high | ongudai | Bots/Bot1 (BotGlider) | 11.48 | +0.25 | 34.56 | 9.83 |
| high | ongudai | Bots/Bot2 (BotGlider) | 13.46 | +0.51 | 35.81 | 11.10 |
| high | ongudai | Bots/Bot3 (BotGlider) | 11.79 | -1.15 | 33.00 | 9.74 |
| high | ongudai | EasterEggs (EasterEggs) | 12.22 | +1.25 | 40.33 | 9.63 |
| high | ongudai | EasterEggs/people_1 (EggPeople) | 11.81 | +0.73 | 39.22 | 9.60 |
| high | ongudai | EasterEggs/uaz_2 (EggUaz) | 11.93 | +0.61 | 38.85 | 9.49 |
| high | ongudai | EasterEggs/herds_3 (EggHerds) | 11.88 | +0.38 | 37.89 | 9.51 |
| high | ongudai | Air (Atmosphere) | 10.07 | -1.33 | 38.35 | 9.11 |
| high | ongudai | Air/Clouds (CloudLayer) | 10.67 | -0.65 | 34.18 | 9.26 |
| high | ongudai | Air/Cirrus (CirrusLayer) | 11.84 | +0.31 | 41.16 | 9.12 |
| high | ongudai | Air/DustDevils (DustDevils) | 12.92 | +0.75 | 43.56 | 9.28 |
| high | ongudai | Air/Birds (BirdFlock) | 12.07 | -0.59 | 41.87 | 10.11 |
| high | ongudai | Air/ThermalSigns (ThermalSigns) | 12.43 | -0.18 | 46.94 | 9.78 |
| high | ongudai | AirRuntime (AirRuntime) | 12.47 | +0.37 | 36.06 | 9.61 |
| high | ongudai | DebugOverlays (DebugOverlays) | 12.85 | +1.19 | 37.14 | 9.53 |
| low | ongudai | Environment (SkyEnvironment) | 9.01 | -2.45 | 33.59 | 3.72 |
| low | ongudai | Environment/SunClock (SunClock) | 10.75 | -0.90 | 30.68 | 3.74 |
| low | ongudai | Environment/SunGlare (SunGlare) | 8.65 | -2.93 | 25.63 | 3.79 |
| low | ongudai | Terrain (Terrain) | 9.55 | -1.08 | 19.38 | 3.73 |
| low | ongudai | Terrain/Mesh (TerrainRenderer) | 10.24 | -0.02 | 29.68 | 3.66 |
| low | ongudai | Terrain/Trees (TerrainTreeModels) | 10.03 | -0.14 | 30.97 | 3.77 |
| low | ongudai | Terrain/ForestImpostors (ForestImpostors) | 9.69 | -0.32 | 26.80 | 3.79 |
| low | ongudai | Terrain/Wind (TerrainWind) | 9.45 | -0.36 | 20.84 | 3.85 |
| low | ongudai | Terrain/Rocks (RockScatter) | 10.08 | +0.12 | 38.11 | 3.95 |
| low | ongudai | Terrain/Shrubs (ShrubScatter) | 10.05 | -0.01 | 38.88 | 3.95 |
| low | ongudai | Glider (Glider) | 9.34 | -0.55 | 32.53 | 4.01 |
| low | ongudai | Glider/Visual (GliderVisual) | 9.46 | -0.28 | 32.63 | 4.08 |
| low | ongudai | InputController (InputController) | 10.30 | +0.62 | 39.56 | 4.17 |
| low | ongudai | FlightInstrument (FlightInstrument) | 10.70 | +1.22 | 37.97 | 4.36 |
| low | ongudai | InstrumentOverlay (InstrumentOverlay) | 10.16 | +0.70 | 33.15 | 3.98 |
| low | ongudai | InstrumentOverlay/FlightInstrument (FlightInstrument) | 10.13 | +0.53 | 34.78 | 3.97 |
| low | ongudai | VarioAudio (VarioAudio) | 9.53 | -0.21 | 31.94 | 3.85 |
| low | ongudai | FlightAudio (FlightAudio) | 10.09 | +0.39 | 38.23 | 3.80 |
| low | ongudai | WindFieldDebug (WindFieldDebug) | 10.38 | +1.31 | 38.67 | 3.75 |
| low | ongudai | WorldLink (WorldLink) | 8.87 | +0.14 | 25.08 | 3.84 |
| low | ongudai | WorldLink/WorldObjects (WorldObjects) | 9.31 | +0.40 | 34.45 | 3.89 |
| low | ongudai | Bots (BotPilots) | 8.20 | -0.81 | 23.87 | 3.91 |
| low | ongudai | Bots/Bot0 (BotGlider) | 9.13 | +0.22 | 22.76 | 3.92 |
| low | ongudai | Bots/Bot1 (BotGlider) | 8.82 | -0.03 | 25.67 | 3.88 |
| low | ongudai | Bots/Bot2 (BotGlider) | 9.02 | +0.41 | 29.02 | 3.87 |
| low | ongudai | Bots/Bot3 (BotGlider) | 8.56 | -0.43 | 28.37 | 3.87 |
| low | ongudai | EasterEggs (EasterEggs) | 9.27 | -0.47 | 31.01 | 4.03 |
| low | ongudai | EasterEggs/people_1 (EggPeople) | 9.82 | +0.12 | 32.45 | 3.84 |
| low | ongudai | EasterEggs/uaz_2 (EggUaz) | 9.94 | +0.37 | 30.94 | 3.80 |
| low | ongudai | EasterEggs/herds_3 (EggHerds) | 10.13 | +0.49 | 35.04 | 3.82 |
| low | ongudai | Air (Atmosphere) | 6.96 | -2.65 | 30.55 | 3.84 |
| low | ongudai | Air/Clouds (CloudLayer) | 9.10 | -0.25 | 38.66 | 3.88 |
| low | ongudai | Air/Cirrus (CirrusLayer) | 10.13 | +0.40 | 37.24 | 3.77 |
| low | ongudai | Air/DustDevils (DustDevils) | 10.24 | -0.18 | 39.39 | 3.74 |
| low | ongudai | Air/Birds (BirdFlock) | 8.93 | -1.44 | 36.95 | 3.78 |
| low | ongudai | Air/ThermalSigns (ThermalSigns) | 9.97 | -0.01 | 34.08 | 3.99 |
| low | ongudai | AirRuntime (AirRuntime) | 10.27 | +0.55 | 35.18 | 4.01 |
| low | ongudai | DebugOverlays (DebugOverlays) | 10.66 | +0.70 | 36.58 | 4.02 |
| medium | ongudai | Environment (SkyEnvironment) | 9.93 | -1.53 | 34.65 | 7.46 |
| medium | ongudai | Environment/SunClock (SunClock) | 11.46 | -0.11 | 43.59 | 7.36 |
| medium | ongudai | Environment/SunGlare (SunGlare) | 9.96 | -1.79 | 33.91 | 7.48 |
| medium | ongudai | Terrain (Terrain) | 10.21 | -1.14 | 23.00 | 7.32 |
| medium | ongudai | Terrain/Mesh (TerrainRenderer) | 10.78 | -0.69 | 31.66 | 7.44 |
| medium | ongudai | Terrain/Trees (TerrainTreeModels) | 10.85 | -0.37 | 34.31 | 7.57 |
| medium | ongudai | Terrain/ForestImpostors (ForestImpostors) | 11.07 | +0.29 | 30.93 | 7.81 |
| medium | ongudai | Terrain/Grass (GrassField) | 11.31 | +0.28 | 34.29 | 7.79 |
| medium | ongudai | Terrain/Wind (TerrainWind) | 9.92 | -1.54 | 21.22 | 7.82 |
| medium | ongudai | Terrain/Rocks (RockScatter) | 11.19 | -0.23 | 28.57 | 7.91 |
| medium | ongudai | Terrain/Shrubs (ShrubScatter) | 10.75 | -0.65 | 35.28 | 8.08 |
| medium | ongudai | Glider (Glider) | 10.73 | -1.01 | 28.80 | 8.99 |
| medium | ongudai | Glider/Visual (GliderVisual) | 10.95 | -0.82 | 29.44 | 8.89 |
| medium | ongudai | InputController (InputController) | 11.11 | -0.06 | 38.72 | 8.92 |
| medium | ongudai | FlightInstrument (FlightInstrument) | 10.39 | -0.33 | 29.63 | 8.14 |
| medium | ongudai | InstrumentOverlay (InstrumentOverlay) | 10.61 | -0.13 | 37.04 | 8.03 |
| medium | ongudai | InstrumentOverlay/FlightInstrument (FlightInstrument) | 10.48 | -0.29 | 29.64 | 7.86 |
| medium | ongudai | VarioAudio (VarioAudio) | 10.02 | -0.62 | 28.11 | 7.90 |
| medium | ongudai | FlightAudio (FlightAudio) | 10.70 | +0.35 | 38.20 | 7.92 |
| medium | ongudai | WindFieldDebug (WindFieldDebug) | 9.88 | -0.20 | 20.98 | 8.19 |
| medium | ongudai | WorldLink (WorldLink) | 9.99 | -0.10 | 26.90 | 8.32 |
| medium | ongudai | WorldLink/WorldObjects (WorldObjects) | 9.91 | -0.42 | 24.56 | 8.02 |
| medium | ongudai | Bots (BotPilots) | 9.77 | -0.68 | 21.70 | 8.24 |
| medium | ongudai | Bots/Bot0 (BotGlider) | 9.85 | -0.40 | 24.99 | 8.13 |
| medium | ongudai | Bots/Bot1 (BotGlider) | 9.95 | +0.01 | 33.98 | 8.11 |
| medium | ongudai | Bots/Bot2 (BotGlider) | 10.06 | -1.22 | 24.75 | 8.10 |
| medium | ongudai | Bots/Bot3 (BotGlider) | 11.02 | -0.63 | 31.18 | 8.74 |
| medium | ongudai | EasterEggs (EasterEggs) | 10.19 | -0.54 | 32.45 | 8.13 |
| medium | ongudai | EasterEggs/people_1 (EggPeople) | 10.56 | -0.62 | 27.30 | 8.03 |
| medium | ongudai | EasterEggs/uaz_2 (EggUaz) | 10.88 | -0.26 | 36.60 | 7.98 |
| medium | ongudai | EasterEggs/herds_3 (EggHerds) | 10.95 | -0.19 | 28.25 | 7.74 |
| medium | ongudai | Air (Atmosphere) | 8.82 | -2.24 | 33.00 | 7.90 |
| medium | ongudai | Air/Clouds (CloudLayer) | 9.32 | -1.80 | 25.07 | 7.67 |
| medium | ongudai | Air/Cirrus (CirrusLayer) | 11.00 | -0.28 | 29.33 | 7.59 |
| medium | ongudai | Air/DustDevils (DustDevils) | 11.29 | +0.28 | 35.91 | 7.75 |
| medium | ongudai | Air/Birds (BirdFlock) | 9.96 | -1.27 | 34.83 | 7.79 |
| medium | ongudai | Air/ThermalSigns (ThermalSigns) | 10.52 | -1.29 | 29.00 | 7.80 |
| medium | ongudai | AirRuntime (AirRuntime) | 10.88 | -0.72 | 29.40 | 7.82 |
| medium | ongudai | DebugOverlays (DebugOverlays) | 11.65 | +0.72 | 34.72 | 7.85 |

## Периодические работы главного потока (5 вызовов, мс на вызов)

| пресет | место | работа | среднее, мс | худший, мс |
|---|---|---|---|---|
| high | ongudai | atmo.refresh_now | 28.17 | 28.87 |
| high | ongudai | atmo.refresh_now+AirThermals.build | 29.09 | 30.01 |
| high | ongudai | clouds._select | 30.90 | 31.52 |
| high | ongudai | clouds._update_light | 0.02 | 0.02 |
| high | ongudai | clouds._visible_records | 0.24 | 0.25 |
| low | ongudai | atmo.refresh_now | 28.69 | 29.69 |
| low | ongudai | atmo.refresh_now+AirThermals.build | 29.36 | 30.27 |
| low | ongudai | clouds._select | 30.98 | 33.42 |
| low | ongudai | clouds._update_light | 0.02 | 0.03 |
| low | ongudai | clouds._visible_records | 0.11 | 0.12 |
| medium | altai | atmo.refresh_now | 36.65 | 69.41 |
| medium | altai | atmo.refresh_now+AirThermals.build | 28.20 | 28.38 |
| medium | altai | clouds._select | 30.00 | 30.15 |
| medium | altai | clouds._update_light | 0.03 | 0.04 |
| medium | altai | clouds._visible_records | 0.18 | 0.21 |
| medium | ongudai | atmo.refresh_now | 28.46 | 29.46 |
| medium | ongudai | atmo.refresh_now+AirThermals.build | 30.87 | 33.84 |
| medium | ongudai | clouds._select | 31.45 | 33.65 |
| medium | ongudai | clouds._update_light | 0.02 | 0.02 |
| medium | ongudai | clouds._visible_records | 0.17 | 0.19 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 3568@0.0/0, 338@0.1/0, 304@0.3/0, 65@0.4/0, 58@1.1/0 |
| high | ongudai | 3643@0.0/0, 235@0.1/0, 190@0.3/0, 63@0.4/0 |
| high | ongudai | 3762@0.0/0, 213@0.1/0, 182@0.3/0, 61@0.4/0, 347@5.9/0 |
| high | ongudai | 3535@0.0/0, 215@0.1/0, 189@0.3/0, 64@0.4/0, 211@5.9/0 |
| high | ongudai | 3705@0.0/0, 211@0.1/0, 196@0.3/0, 65@0.4/0, 223@5.9/0 |
| high | ongudai | 3680@0.0/0, 220@0.1/0, 165@0.3/0, 61@0.4/0, 213@5.9/0, 54@60.1/0 |
| high | ongudai | 3660@0.0/0, 220@0.1/0, 167@0.3/0, 55@0.4/0, 61@0.5/0, 214@5.9/0, 54@69.9/2, 51@70.0/4, 102@70.1/5, 56@71.0/5 |
| low | ongudai | 3613@0.0/0, 374@0.1/0, 244@0.3/0, 51@0.4/0 |
| low | ongudai | 3638@0.0/0, 207@0.1/0, 150@0.3/0, 75@0.4/0, 366@5.9/0, 55@16.1/0 |
| low | ongudai | 3748@0.0/0, 241@0.1/0, 129@0.3/0, 55@0.3/0, 210@5.9/0 |
| low | ongudai | 3658@0.0/0, 208@0.1/0, 155@0.3/0, 73@0.4/0, 227@5.9/0, 69@69.9/5, 54@70.6/5, 54@74.7/0 |
| medium | altai | 4555@0.0/0, 262@0.1/0, 200@0.3/0 |
| medium | altai | 4476@0.0/0, 262@0.1/0, 192@0.3/0, 55@0.4/0, 62@5.1/0 |
| medium | ongudai | 3992@0.0/0, 461@0.1/0, 298@0.3/0, 72@0.4/0 |
| medium | ongudai | 3716@0.0/0, 221@0.1/0, 194@0.3/0, 56@0.4/0 |
| medium | ongudai | 3583@0.0/0, 211@0.1/0, 162@0.3/0, 52@0.4/0, 350@5.9/0, 51@30.1/0 |
| medium | ongudai | 3725@0.0/0, 212@0.1/0, 168@0.3/0, 55@0.4/0, 214@5.9/0 |
| medium | ongudai | 3730@0.0/0, 216@0.1/0, 176@0.3/0, 56@0.4/0, 215@5.9/0, 52@11.0/0, 58@14.1/0 |
| medium | ongudai | 3712@0.0/0, 221@0.1/0, 193@0.3/0, 61@0.4/0, 209@5.9/0 |
| medium | ongudai | 3613@0.0/0, 216@0.1/0, 173@0.3/0, 51@0.4/0, 52@0.4/0, 222@5.9/0, 99@70.1/5, 56@70.8/5, 59@74.2/7 |

