## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 4.92 | 5.29 | 4.87 | 5.18 | 1.59 | 10.54 | 966 | 3444 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.12 | 5.52 | 5.08 | 5.34 | 1.55 | 8.59 | 1001 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 4.60 | 4.77 | 4.55 | 4.69 | 1.26 | 10.27 | 779 | 3360 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.38 | 4.68 | 4.33 | 4.49 | 1.19 | 9.48 | 652 | 2758 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.73 | 4.94 | 4.68 | 4.83 | 1.19 | 9.25 | 676 | 2338 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.19 | 4.97 | 4.14 | 4.49 | 0.97 | 8.58 | 473 | 2617 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.29 | 34.02 | 12.53 | 13.30 | 1.27 | 29.53 | 9.45 | 805 |
| high | ongudai | chase@30 | 15.38 | 32.09 | 12.94 | 13.80 | 1.36 | 28.14 | 8.72 | 992 |
| high | ongudai | chase@60 | 14.85 | 46.87 | 11.18 | 12.03 | 1.35 | 26.94 | 10.08 | 1015 |
| medium | ongudai | cockpit@2 | 14.84 | 36.71 | 8.31 | 8.65 | 1.11 | 34.89 | 9.18 | 497 |
| medium | ongudai | chase@30 | 14.20 | 28.70 | 8.83 | 9.11 | 1.21 | 25.09 | 8.39 | 676 |
| medium | ongudai | chase@60 | 13.95 | 45.09 | 8.73 | 9.23 | 1.18 | 32.87 | 9.30 | 691 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.33 (-7 %) | -0.01 (-0 %) | -0.04 (-1 %) | -0.13 | -3 |

Шум (base2 − base): +0.13, -0.03, -0.20 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.20 (-5 %) | -0.01 (-0 %) | -0.05 (-1 %) | -0.09 | -2 |

Шум (base2 − base): -0.01, -0.01, +0.18 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.86 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.10 | 3.39 | 2.82 | 3.10 | 63.8 % |
| Render Depth Pre-Pass | 0.77 | 0.64 | 0.78 | 0.73 | 15.0 % |
| Render Directional/SpotLight Shadows | 0.43 | 0.53 | 0.35 | 0.44 | 9.0 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.23 | 0.15 | 3.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.7 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.08 | 0.03 | 0.7 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Pre Opaque Render | 0.00 | 0.02 | 0.01 | 0.01 | 0.2 % |

### medium+nocloudfx / ongudai (всего 4.36 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.04 | 3.37 | 2.62 | 3.01 | 69.0 % |
| Render Depth Pre-Pass | 0.61 | 0.58 | 0.70 | 0.63 | 14.5 % |
| Render Directional/SpotLight Shadows | 0.17 | 0.24 | 0.09 | 0.17 | 3.8 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.23 | 0.15 | 3.5 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 2.0 % |
| Render CanvasItems | 0.09 | 0.09 | 0.07 | 0.08 | 1.9 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.5 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.02 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 32 | 1.32 | 4.90 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8225 | 12.93 | 25.16 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5651 | 12.90 | 21.99 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 34 | 1.43 | 5.89 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 641 | 8211 | 12.81 | 25.95 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5553 | 12.68 | 21.22 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 394@0.1/0, 278@0.3/0, 191@0.4/0, 55@0.6/0 |
| high | ongudai | 5311@0.0/0, 321@0.1/0, 207@0.3/0, 178@0.4/0, 241@15.4/0, 51@15.5/0, 50@22.1/0, 81@24.9/0, 51@30.1/0 |
| high | ongudai | 5194@0.0/0, 306@0.1/0, 203@0.3/0, 159@0.4/0, 74@0.5/0, 114@5.0/0, 73@5.1/0, 68@15.4/0, 94@25.0/0, 65@39.1/0, 55@43.1/0, 82@45.0/0, 57@49.1/0, 52@52.1/0, 60@60.1/0, 58@62.1/0 |
| medium | ongudai | 443@0.1/0, 314@0.3/0, 178@0.4/0, 70@0.9/0 |
| medium | ongudai | 5264@0.0/0, 334@0.1/0, 186@0.3/0, 153@0.4/0, 56@0.5/0, 50@0.7/0, 61@4.2/0, 51@5.1/0, 185@15.5/0, 61@24.2/0 |
| medium | ongudai | 5212@0.0/0, 335@0.1/0, 216@0.3/0, 162@0.4/0, 70@4.5/0, 68@15.4/0, 120@24.5/0, 63@39.1/0, 51@43.1/0, 83@44.5/0, 62@50.4/0, 52@57.0/0, 74@60.1/0, 62@62.1/0 |

