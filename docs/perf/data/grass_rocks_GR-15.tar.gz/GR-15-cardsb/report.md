## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.01 | 5.46 | 4.96 | 5.29 | 1.48 | 9.81 | 966 | 3603 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.19 | 11.07 | 5.08 | 5.33 | 1.61 | 9.98 | 997 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 4.89 | 5.07 | 4.84 | 4.96 | 1.36 | 13.35 | 780 | 3519 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.49 | 4.72 | 4.45 | 4.60 | 1.28 | 9.06 | 657 | 2845 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.72 | 8.13 | 4.63 | 4.81 | 1.15 | 12.83 | 681 | 2339 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.28 | 4.72 | 4.24 | 4.62 | 1.11 | 8.33 | 480 | 2704 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.38 | 47.95 | 12.84 | 13.75 | 1.22 | 35.25 | 9.47 | 805 |
| high | ongudai | chase@30 | 15.43 | 26.98 | 13.10 | 14.39 | 1.37 | 24.91 | 8.82 | 993 |
| high | ongudai | chase@60 | 14.83 | 40.16 | 11.33 | 12.14 | 1.35 | 27.96 | 9.94 | 1015 |
| medium | ongudai | cockpit@2 | 15.24 | 34.63 | 8.36 | 8.81 | 1.12 | 38.28 | 9.17 | 504 |
| medium | ongudai | chase@30 | 14.09 | 30.27 | 8.93 | 9.32 | 1.20 | 26.09 | 8.92 | 681 |
| medium | ongudai | chase@60 | 14.15 | 43.27 | 8.79 | 9.18 | 1.20 | 25.05 | 11.18 | 696 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.44 (-9 %) | +0.01 (+0 %) | -0.14 (-3 %) | -0.19 | -4 |

Шум (base2 − base): +0.12, -0.00, -0.24 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.35 (-8 %) | -0.01 (-0 %) | -0.16 (-4 %) | -0.17 | -4 |

Шум (base2 − base): +0.15, -0.03, -0.25 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.99 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.09 | 3.41 | 2.88 | 3.13 | 62.7 % |
| Render Depth Pre-Pass | 0.81 | 0.66 | 0.86 | 0.78 | 15.6 % |
| Render Directional/SpotLight Shadows | 0.43 | 0.51 | 0.42 | 0.45 | 9.1 % |
| Render 3D Transparent Pass | 0.16 | 0.11 | 0.36 | 0.21 | 4.3 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.08 | 1.5 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.05 | 0.05 | 0.06 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.02 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Pack 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |

### medium+nocloudfx / ongudai (всего 4.47 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.92 | 3.34 | 2.92 | 3.06 | 68.5 % |
| Render Depth Pre-Pass | 0.77 | 0.57 | 0.64 | 0.66 | 14.7 % |
| Render 3D Transparent Pass | 0.14 | 0.11 | 0.30 | 0.18 | 4.1 % |
| Render Directional/SpotLight Shadows | 0.16 | 0.24 | 0.10 | 0.17 | 3.7 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 2.0 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.06 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.2 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 33 | 1.37 | 4.61 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8311 | 13.07 | 25.14 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5637 | 12.87 | 22.15 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 31 | 1.31 | 3.77 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 640 | 8141 | 12.72 | 25.84 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 439 | 5529 | 12.59 | 21.22 | 213723 | 487 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 459@0.1/0, 324@0.3/0, 174@0.4/0, 75@2.1/0, 52@2.4/0, 63@3.7/0 |
| high | ongudai | 5278@0.0/0, 339@0.1/0, 240@0.3/0, 158@0.4/0, 60@4.8/0, 215@15.5/0, 58@24.8/0 |
| high | ongudai | 5321@0.0/0, 330@0.1/0, 183@0.3/0, 157@0.4/0, 81@0.5/0, 55@4.5/0, 66@15.4/0, 61@20.1/0, 143@24.6/0, 53@24.7/0, 62@39.1/0, 64@44.5/0, 61@60.1/0 |
| medium | ongudai | 430@0.1/0, 290@0.3/0, 157@0.4/0, 51@1.0/0, 55@1.9/0 |
| medium | ongudai | 5307@0.0/0, 338@0.1/0, 204@0.3/0, 156@0.4/0, 50@0.5/0, 93@4.7/0, 215@15.5/0, 60@24.6/0 |
| medium | ongudai | 5202@0.0/0, 316@0.1/0, 195@0.3/0, 152@0.4/0, 63@0.5/0, 70@4.6/0, 65@15.4/0, 143@24.6/0, 60@39.0/0, 116@44.6/0, 58@60.1/0, 50@62.0/0 |

