## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 4.94 | 5.22 | 4.90 | 5.11 | 1.37 | 9.79 | 966 | 3444 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.27 | 18.90 | 5.08 | 5.49 | 1.70 | 11.45 | 1001 | 2812 | 98 |
| high+nocloudfx | ongudai | cockpit@2 | 4.59 | 4.77 | 4.54 | 4.69 | 1.13 | 21.28 | 780 | 3361 | 90 |
| medium+nocloudfx | ongudai | chase@30 | 4.42 | 4.75 | 4.38 | 4.68 | 1.23 | 8.21 | 657 | 2759 | 76 |
| medium+nocloudfx | ongudai | chase@60 | 4.72 | 4.93 | 4.68 | 4.83 | 1.30 | 7.71 | 679 | 2339 | 79 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.15 | 4.44 | 4.11 | 4.26 | 1.09 | 11.05 | 480 | 2619 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.34 | 34.15 | 12.58 | 14.05 | 1.26 | 33.52 | 10.05 | 805 |
| high | ongudai | chase@30 | 15.21 | 25.69 | 12.96 | 13.97 | 1.35 | 29.64 | 8.32 | 993 |
| high | ongudai | chase@60 | 15.05 | 48.71 | 11.22 | 12.06 | 1.34 | 28.69 | 9.95 | 1015 |
| medium | ongudai | cockpit@2 | 15.01 | 36.39 | 8.20 | 9.20 | 1.10 | 41.44 | 8.40 | 503 |
| medium | ongudai | chase@30 | 14.24 | 25.91 | 8.86 | 9.12 | 1.23 | 24.52 | 8.41 | 682 |
| medium | ongudai | chase@60 | 13.74 | 36.35 | 8.82 | 9.50 | 1.18 | 23.76 | 9.11 | 696 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.36 (-7 %) | +0.02 (+0 %) | +0.00 (+0 %) | -0.11 | -2 |

Шум (base2 − base): +0.16, +0.00, -0.20 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.27 (-6 %) | -0.01 (-0 %) | -0.07 (-2 %) | -0.11 | -3 |

Шум (base2 − base): +0.11, -0.02, -0.19 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 4.85 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.12 | 3.41 | 2.80 | 3.11 | 64.1 % |
| Render Depth Pre-Pass | 0.78 | 0.66 | 0.78 | 0.74 | 15.2 % |
| Render Directional/SpotLight Shadows | 0.41 | 0.52 | 0.37 | 0.43 | 8.9 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.23 | 0.15 | 3.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.8 % |
| Render CanvasItems | 0.08 | 0.08 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.5 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.06 | 0.03 | 0.5 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Pack 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |

### medium+nocloudfx / ongudai (всего 4.41 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.96 | 3.36 | 2.74 | 3.02 | 68.5 % |
| Render Depth Pre-Pass | 0.64 | 0.56 | 0.69 | 0.63 | 14.4 % |
| Render Directional/SpotLight Shadows | 0.20 | 0.26 | 0.12 | 0.19 | 4.4 % |
| Render 3D Transparent Pass | 0.12 | 0.11 | 0.23 | 0.15 | 3.5 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 2.0 % |
| Render CanvasItems | 0.09 | 0.09 | 0.07 | 0.08 | 1.9 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.03 | 0.01 | 0.3 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| Pre Opaque Render | 0.01 | 0.00 | 0.01 | 0.01 | 0.2 % |
| Pack 3D Cluster Elements | 0.01 | 0.01 | 0.2 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 33 | 1.39 | 4.74 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8300 | 13.05 | 25.38 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5607 | 12.80 | 22.04 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 36 | 1.50 | 5.90 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 641 | 8124 | 12.67 | 25.55 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5512 | 12.58 | 21.27 | 213723 | 488 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 496@0.1/0, 308@0.3/0, 163@0.4/0, 70@0.5/0, 60@1.1/0, 59@1.1/0 |
| high | ongudai | 5258@0.0/0, 318@0.1/0, 213@0.3/0, 162@0.4/0, 134@4.8/0, 222@15.4/0, 124@24.8/0, 56@30.1/0 |
| high | ongudai | 5208@0.0/0, 343@0.1/0, 204@0.3/0, 181@0.4/0, 70@15.4/0, 70@24.8/0, 60@39.0/0, 56@43.1/0, 54@44.8/0, 62@60.1/0, 68@62.1/0 |
| medium | ongudai | 432@0.1/0, 280@0.3/0, 155@0.4/0, 51@0.5/0, 56@1.4/0, 52@2.1/0, 50@2.4/0 |
| medium | ongudai | 5251@0.0/0, 312@0.1/0, 178@0.3/0, 149@0.4/0, 59@1.1/0, 53@4.1/0, 56@5.2/0, 216@15.4/0, 130@25.3/0 |
| medium | ongudai | 5239@0.0/0, 338@0.1/0, 191@0.3/0, 162@0.4/0, 62@0.5/0, 59@1.1/0, 51@4.0/0, 82@5.2/0, 64@10.0/0, 66@15.4/0, 55@16.1/0, 54@19.1/0, 59@22.1/0, 132@25.2/0, 52@39.0/0, 61@45.1/0 |

