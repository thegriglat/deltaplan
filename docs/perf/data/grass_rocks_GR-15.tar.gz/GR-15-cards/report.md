## Окружение

- high / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 3000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`
- medium / ongudai: `{"adapter": "NVIDIA GeForce RTX 4070 SUPER", "driver": "1.3.277", "fog": false, "glow": true, "max_fps": 0, "msaa_3d": 1, "scale_3d": 1.0, "scaling_mode": 0, "sdfgi": false, "shadow": true, "shadow_blur": 1.5, "shadow_max_m": 2000.0, "shadow_mode": 2, "size": "(1918, 1036)", "splits": [0.0500000007450581, 0.200000002980232, 0.5], "ssao": false, "ssil": false, "ssr": false, "tonemap": 4, "volumetric_fog": false, "vsync": 0}`

## База (пауза на отметке, среднее base и base2)

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | вызовов | примитивов, тыс. | облаков |
|---|---|---|---|---|---|---|---|---|---|---|---|
| high+nocloudfx | ongudai | chase@30 | 5.03 | 5.22 | 4.98 | 5.15 | 1.50 | 10.63 | 966 | 3603 | 96 |
| high+nocloudfx | ongudai | chase@60 | 5.20 | 10.45 | 5.10 | 5.29 | 1.50 | 10.29 | 1001 | 2812 | 99 |
| high+nocloudfx | ongudai | cockpit@2 | 5.01 | 5.35 | 4.96 | 5.27 | 1.35 | 24.32 | 779 | 3518 | 89 |
| medium+nocloudfx | ongudai | chase@30 | 4.48 | 5.19 | 4.43 | 4.57 | 1.31 | 7.36 | 657 | 2845 | 77 |
| medium+nocloudfx | ongudai | chase@60 | 4.72 | 4.94 | 4.67 | 4.85 | 1.27 | 7.88 | 679 | 2339 | 78 |
| medium+nocloudfx | ongudai | cockpit@2 | 4.31 | 4.60 | 4.26 | 4.52 | 1.09 | 11.50 | 479 | 2704 | 72 |

## Полёт без паузы (настоящая нагрузка CPU), VSync и предел кадров сняты

| пресет | место | ракурс@с | кадр, мс | 1%-худших, мс | GPU окна, мс | GPU 1%, мс | CPU отрисовки, мс | process макс. за 1 с, мс | physics макс. за 1 с, мс | вызовов |
|---|---|---|---|---|---|---|---|---|---|---|
| high | ongudai | cockpit@2 | 16.83 | 65.63 | 12.88 | 13.66 | 1.23 | 25.99 | 10.11 | 805 |
| high | ongudai | chase@30 | 15.62 | 26.51 | 13.09 | 13.96 | 1.37 | 26.03 | 8.18 | 993 |
| high | ongudai | chase@60 | 15.12 | 43.18 | 11.36 | 13.40 | 1.36 | 27.44 | 8.64 | 1015 |
| medium | ongudai | cockpit@2 | 15.03 | 39.34 | 8.32 | 8.72 | 1.09 | 35.47 | 11.01 | 504 |
| medium | ongudai | chase@30 | 14.22 | 47.71 | 8.92 | 9.59 | 1.22 | 29.68 | 10.96 | 681 |
| medium | ongudai | chase@60 | 14.00 | 44.71 | 8.77 | 9.28 | 1.21 | 26.57 | 9.51 | 696 |

## Опыты: Δ GPU окна к базе, мс (в скобках — % от GPU базы); по отметкам

### high+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.48 (-10 %) | +0.00 (+0 %) | -0.16 (-3 %) | -0.21 | -4 |

Шум (base2 − base): +0.13, -0.02, -0.21 мс

### medium+nocloudfx / ongudai

| опыт | chase@30 | chase@60 | cockpit@2 | среднее Δ, мс | среднее, % |
|---|---|---|---|---|---|
| nograss | -0.31 (-7 %) | -0.02 (-0 %) | -0.22 (-5 %) | -0.18 | -4 |

Шум (base2 − base): +0.16, +0.00, -0.25 мс

## Проходы GPU (метки движка, --gpu-profile), база, мс/кадр

### high+nocloudfx / ongudai (всего 5.03 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 3.08 | 3.41 | 2.90 | 3.13 | 62.1 % |
| Render Depth Pre-Pass | 0.81 | 0.65 | 0.96 | 0.80 | 16.0 % |
| Render Directional/SpotLight Shadows | 0.47 | 0.53 | 0.44 | 0.48 | 9.5 % |
| Render 3D Transparent Pass | 0.16 | 0.11 | 0.36 | 0.21 | 4.2 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.7 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.6 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.4 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.0 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.02 | 0.01 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| Pre Opaque Render | 0.01 | 0.01 | 0.00 | 0.01 | 0.1 % |

### medium+nocloudfx / ongudai (всего 4.48 мс)

| проход | chase@30 | chase@60 | cockpit@2 | среднее | доля |
|---|---|---|---|---|---|
| Render Opaque Pass | 2.89 | 3.35 | 2.90 | 3.05 | 68.1 % |
| Render Depth Pre-Pass | 0.77 | 0.57 | 0.69 | 0.67 | 15.1 % |
| Render 3D Transparent Pass | 0.15 | 0.11 | 0.29 | 0.18 | 4.1 % |
| Render Directional/SpotLight Shadows | 0.17 | 0.25 | 0.10 | 0.17 | 3.9 % |
| Glow | 0.09 | 0.09 | 0.09 | 0.09 | 1.9 % |
| Render CanvasItems | 0.08 | 0.09 | 0.07 | 0.08 | 1.8 % |
| Tonemap | 0.07 | 0.07 | 0.07 | 0.07 | 1.6 % |
| Resolve | 0.05 | 0.05 | 0.05 | 0.05 | 1.1 % |
| Resolve MSAA | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Copy Depth Texture | 0.02 | 0.02 | 0.02 | 0.02 | 0.4 % |
| Render Sky | 0.01 | 0.01 | 0.01 | 0.01 | 0.3 % |
| > Bake 3D Cluster | 0.01 | 0.01 | 0.02 | 0.01 | 0.3 % |
| Setup Shadows | 0.01 | 0.01 | 0.01 | 0.01 | 0.1 % |
| Render 3D Cluster Elements | 0.01 | 0.01 | 0.1 % |

## Порции GPU задач воздуха (DP_AIR_CHUNK_LOG: загрузка и пересчёт)

| файл | задача | порций | GPU всего, мс | средн. порция, мс | макс. порция, мс | запусков | запусков/порцию |
|---|---|---|---|---|---|---|---|
| high_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 35 | 1.47 | 5.20 | 6066 | 253 |
| high_ongudai_load_air_chunks.jsonl | AirPicardJob | 636 | 8186 | 12.87 | 25.13 | 372792 | 586 |
| high_ongudai_load_air_chunks.jsonl | AirWindowJob | 438 | 5646 | 12.89 | 22.41 | 213723 | 488 |
| medium_ongudai_load_air_chunks.jsonl | AirPhaseJob | 24 | 33 | 1.37 | 4.44 | 6066 | 253 |
| medium_ongudai_load_air_chunks.jsonl | AirPicardJob | 640 | 8237 | 12.87 | 25.78 | 372792 | 582 |
| medium_ongudai_load_air_chunks.jsonl | AirWindowJob | 439 | 5544 | 12.63 | 21.38 | 213723 | 487 |

## Рывки > 50 мс за прогон (не на паузе)

| пресет | место | рывки (мс @ сим.с, стадия AirRuntime) |
|---|---|---|
| high | ongudai | 466@0.1/0, 308@0.3/0, 201@0.4/0, 52@0.5/0, 54@2.1/0, 104@4.1/0 |
| high | ongudai | 5276@0.0/0, 318@0.1/0, 216@0.3/0, 190@0.4/0, 58@0.7/0, 71@4.8/0, 200@15.5/0, 68@24.9/0 |
| high | ongudai | 5206@0.0/0, 336@0.1/0, 178@0.3/0, 160@0.4/0, 51@1.0/0, 53@2.1/0, 73@4.7/0, 70@5.1/0, 66@15.4/0, 156@24.7/0, 53@39.0/0, 71@44.6/0, 55@60.1/0 |
| medium | ongudai | 501@0.1/0, 316@0.3/0, 158@0.4/0, 64@1.1/0 |
| medium | ongudai | 5334@0.0/0, 338@0.1/0, 184@0.3/0, 171@0.4/0, 71@0.5/0, 135@5.1/0, 219@15.4/0, 160@25.1/0, 63@31.1/0 |
| medium | ongudai | 5246@0.0/0, 326@0.1/0, 202@0.3/0, 169@0.4/0, 140@4.9/0, 65@15.4/0, 88@24.9/0, 65@39.1/0, 56@43.1/0, 70@44.9/0, 56@60.1/0, 51@62.1/0 |

